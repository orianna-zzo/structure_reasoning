from datasets import interleave_datasets, DatasetDict, Dataset
from datasets.arrow_dataset import concatenate_datasets
from itertools import chain

# def combineDict(dictlist):
#     combine = dict()
#     for k, v in ((k, v) for d in dictlist for k, v in d.iteritems()):
#         combine[k].append(v)
#     return combine


def combineDatasetDicts(datasetdict_list):
    combined_column_names = None
    combined_num_columns = None
    combined_train = None
    combined_dev = None
    combined_test = None
    for idx, ds_dict in enumerate(datasetdict_list):
        if idx == 0:
            combined_column_names = ds_dict.column_names
            combined_num_columns = ds_dict.num_columns
            combined_train = ds_dict["train"]
            combined_dev = ds_dict["validation"]
            combined_test = ds_dict["test"]
        else:
            for k in combined_column_names:
                assert combined_column_names[k] == ds_dict.column_names[k]
            for k in combined_num_columns:
                assert combined_num_columns[k] == ds_dict.num_columns[k]

            combined_train = concatenate_datasets([combined_train, ds_dict["train"]])
            combined_dev = concatenate_datasets([combined_dev, ds_dict["validation"]])
            combined_test = concatenate_datasets([combined_test, ds_dict["test"]])

    combined_train = combined_train.flatten_indices()
    combined_dev = combined_dev.flatten_indices()
    combined_test = combined_test.flatten_indices()
    return DatasetDict({"train": combined_train, "validation": combined_dev, "test": combined_test})





