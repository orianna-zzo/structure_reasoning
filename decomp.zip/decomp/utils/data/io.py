"""Data read/write and io functions"""

import csv
import json

def read_tsv(input_file, delimiter="\t", quotechar=None):
    """Reads a tab separated value file."""
    with open(input_file, "r", encoding="utf-8") as f:
        return list(csv.reader(f, delimiter=delimiter, quotechar=quotechar))


def save_jsonl(file_name, data):
    with open(file_name, 'w') as file:
        for d in data:
            file.write(json.dumps(d))
            file.write("\n")


def load_jsonl(file_name):
    with open(file_name, 'r') as file:
        return [json.loads(line.strip()) for line in file]


def save_json(file_name, data):
    with open(file_name, 'w') as file:
        file.write(json.dumps(data))