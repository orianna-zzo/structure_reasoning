"""Data Reader for the SNLI 1.0 data set"""

import os
import logging
# import shutil
from tqdm import tqdm
import abc
import numpy as np


import re
import itertools
import random

from collections import OrderedDict
# import torch
# from utils.embed import load_vocab, find_sentence_ids
from utils.data import read_tsv, load_jsonl
from config.data_config import ENTBANK_DIR

logger = logging.getLogger(__name__)

NLI_3_LABEL = {'entailment': 0, 'neutral': 1, 'contradiction': 2}

# ======== DataReader ========
class EntBankReader(object):
    def __init__(self, task):
        self.task = task
        assert self.task in ["task_1", "task_2", "task_3"]
        self.data_keys = ['id', 'contexts', 'question', 'answer', 'hypothesis', 'hypothesis_id', 'proof',
                          'full_text_proof', 'depth_of_proof', 'length_of_proof', 'inter', 'lisp_proof',
                          'worldtree', 'gold_sent', 'guid']
        # logger.info("EntailmentBank ", task)


    def get_train_examples(self, data_dir, custom_file_name=None):
        logger.info("Read EntailmentBank " + self.task + " Train set...")
        file_path = os.path.join(data_dir, 'dataset', self.task, "train.jsonl")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(load_jsonl(file_path), "train")


    def get_dev_examples(self, data_dir, custom_file_name=None):
        logger.info("Read EntailmentBank " + self.task + " Dev set...")
        file_path = os.path.join(data_dir, 'dataset', self.task, "dev.jsonl")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(load_jsonl(file_path), "dev")


    def get_test_examples(self, data_dir, custom_file_name=None):
        logger.info("Read EntailmentBank " + self.task + " Test set...")
        file_path = os.path.join(data_dir, 'dataset', self.task, "test.jsonl")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(load_jsonl(file_path), "test")

    def _create_examples(self, lines, set_type):
        """Creates examples for the training and dev sets."""
        examples = []

        for (i, line) in enumerate(tqdm(lines)):

            id = line['id']
            contexts = line['meta']['triples']
            question = line['question']
            answer = line['answer']
            hypothesis = line['hypothesis']
            hypothesis_id = line['meta']['hypothesis_id']
            proof =  line['proof']
            full_text_proof = line['full_text_proof']
            depth_of_proof = line['depth_of_proof']
            length_of_proof = line['length_of_proof']
            inter = line['meta']['intermediate_conclusions']
            lisp_proof = line['meta']['lisp_proof']
            worldtree = line['meta']['worldtree_provenance']
            gold_sent = list(set(contexts.keys()) - set(line['meta']['distractors']))
            guid = "%s-%s" % (set_type, i)

            # if depth_of_proof == 0:
            #     print(1)

            ex = dict()
            for k in self.data_keys:
                ex[k] = eval(k)
            examples.append(ex)
        logger.info("  {} examples".format(len(examples)))
        return examples


class NLIDataReader(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def __init__(self):
        self.label2id_dict
        self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}

    @abc.abstractmethod
    def get_train_examples(self, data_dir):
        """ Get train examples """
        pass

    @abc.abstractmethod
    def get_dev_examples(self, data_dir):
        """ Get dev examples """
        pass

    @abc.abstractmethod
    def get_test_examples(self, data_dir):
        """ Get test examples """
        pass


    def label2id(self, label):
        tmp = label.strip()
        return self.label2id_dict[tmp] if tmp in self.label2id_dict.keys() else -1


    def id2label(self, id):
        return self.id2label_dict[id]


class SnliReader(NLIDataReader):
    """
    Data Reader for SNLI1.0
    Notice: There are some '-' gold label in the dataset, they are labeled as -1.
            There should be 5 labels; however in training set most example lacks labels, no label will also be labeld as -1

    Retrun of get_xx_examples: dict list. each example is a dict
    """
    def __init__(self):
        self.label2id_dict = NLI_3_LABEL
        self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
        self.data_keys = ['guid', 'pair_id', 'gold_label_id', 'several_labels', 'premise', 'hypothesis',
                          'premise_bp', 'hypothesis_bp', 'premise_p', 'hypothesis_p'] #,
        # "premise_length", "hypothesis_length"]


    def get_train_examples(self, data_dir, custom_file_name=None):
        logger.info("Read SNLI Train set...")
        file_path = os.path.join(data_dir, "snli_1.0", "snli_1.0_train.txt")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "train")


    def get_dev_examples(self, data_dir, custom_file_name=None):
        logger.info("Read SNLI Dev set...")
        file_path = os.path.join(data_dir, "snli_1.0", "snli_1.0_dev.txt")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "dev")


    def get_test_examples(self, data_dir, custom_file_name=None):
        logger.info("Read SNLI Test set...")
        file_path = os.path.join(data_dir, "snli_1.0", "snli_1.0_test.txt")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test")


    # def get_labels(self):
    #     return self.label2id_dict.keys()
    #
    #
    # def label2id(self, label):
    #     tmp = label.strip()
    #     return self.label2id_dict[tmp] if tmp in self.label2id_dict.keys() else -1
    #
    #
    # def id2label(self, id):
    #     return self.id2label_dict[id]


    def _create_examples(self, lines, set_type):
        """Creates examples for the training and dev sets."""
        examples = []
        head_dict = {k: v for v, k in enumerate(lines[0])}

        for (i, line) in enumerate(tqdm(lines)):
            if i == 0:
                continue
            gold_label_id = self.label2id(line[head_dict['gold_label']])
            several_labels = [self.label2id(line[head_dict['label1']]),
                              self.label2id(line[head_dict['label2']]),
                              self.label2id(line[head_dict['label3']]),
                              self.label2id(line[head_dict['label4']]),
                              self.label2id(line[head_dict['label5']])]

            pair_id = line[head_dict['pairID']].strip()
            premise = line[head_dict['sentence1']].strip()
            if premise[0] == "'" and premise[-1] == "'":
                premise = premise[1:-1].strip()
            if premise[0] == '"' and premise[-1] == '"':
                premise = premise[1:-1].strip()
            if premise[-1] == '.':
                premise = premise[:-1].strip()
            hypothesis = line[head_dict['sentence2']].strip()
            if hypothesis[0] == "'" and hypothesis[-1] == "'":
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[0] == '"' and hypothesis[-1] == '"':
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[-1] == '.':
                hypothesis = hypothesis[:-1].strip()
            premise_bp = line[head_dict['sentence1_binary_parse']].strip()
            hypothesis_bp = line[head_dict['sentence2_binary_parse']].strip()
            premise_p = line[head_dict['sentence1_parse']].strip()
            hypothesis_p = line[head_dict['sentence2_parse']].strip()
            # premise_length = len(premise)
            # hypothesis_length = len(hypothesis)
            guid = "%s-%s" % (set_type, i)

            ex = dict()
            for k in self.data_keys:
                ex[k] = eval(k)
            if 'index' in head_dict.keys():
                ex['index'] = line[head_dict['index']]
            examples.append(ex)
        logger.info("  {} examples".format(len(examples)))
        return examples


class MnliReader(NLIDataReader):
    """
    Data Reader for MNLI
    Notice: There are some '-' gold label in the dataset, they are labeled as -1.
            There should be 5 labels; however in training set most example lacks labels, no label will also be labeld as -1

    Retrun of get_xx_examples: dict list. each example is a dict
    """
    def __init__(self):
        self.label2id_dict = NLI_3_LABEL
        self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
        self.data_keys = ['guid', 'pair_id', 'gold_label_id', 'several_labels', 'premise', 'hypothesis',
                          'premise_bp', 'hypothesis_bp', 'premise_p', 'hypothesis_p', 'genre'] #,
        # "premise_length", "hypothesis_length"]


    def get_train_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MNLI Train set...")
        file_path = os.path.join(data_dir, "multinli_1.0", "multinli_1.0_train.txt")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "train")


    def get_dev_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MNLI Matched Dev set...")
        file_path = os.path.join(data_dir, "multinli_1.0", "multinli_1.0_dev_matched.txt")
        if custom_file_name is not None:
            file_path  =os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "dev")


    def get_test_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MNLI Mismatched Dev set...")
        file_path = os.path.join(data_dir, "multinli_1.0", "multinli_1.0_dev_mismatched.txt")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test")


    # def get_labels(self):
    #     return self.label2id_dict.keys()
    #
    #
    # def label2id(self, label):
    #     tmp = label.strip()
    #     return self.label2id_dict[tmp] if tmp in self.label2id_dict.keys() else -1
    #
    #
    # def id2label(self, id):
    #     return self.id2label_dict[id]


    def _create_examples(self, lines, set_type):
        """Creates examples for the training and dev sets."""
        examples = []
        head_dict = {k: v for v, k in enumerate(lines[0])}
        for (i, line) in enumerate(tqdm(lines)):
            if i == 0:
                continue
            gold_label_id = self.label2id(line[head_dict['gold_label']])
            several_labels = [self.label2id(line[head_dict['label1']]),
                              self.label2id(line[head_dict['label2']]),
                              self.label2id(line[head_dict['label3']]),
                              self.label2id(line[head_dict['label4']]),
                              self.label2id(line[head_dict['label5']])]

            pair_id = line[head_dict['pairID']].strip()
            premise = line[head_dict['sentence1']].strip()
            if premise[0] == "'" and premise[-1] == "'":
                premise = premise[1:-1].strip()
            if premise[0] == '"' and premise[-1] == '"':
                premise = premise[1:-1].strip()
            if premise[-1] == '.':
                premise = premise[:-1].strip()
            hypothesis = line[head_dict['sentence2']].strip()
            if hypothesis[0] == "'" and hypothesis[-1] == "'":
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[0] == '"' and hypothesis[-1] == '"':
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[-1] == '.':
                hypothesis = hypothesis[:-1].strip()
            premise_bp = line[head_dict['sentence1_binary_parse']].strip()
            hypothesis_bp = line[head_dict['sentence2_binary_parse']].strip()
            premise_p = line[head_dict['sentence1_parse']].strip()
            hypothesis_p = line[head_dict['sentence2_parse']].strip()

            # premise_length = len(premise)
            # hypothesis_length = len(hypothesis)
            guid = "%s-%s" % (set_type, i)
            genre = line[head_dict['genre']]

            ex = dict()
            for k in self.data_keys:
                ex[k] = eval(k)
            if 'index' in head_dict.keys():
                ex['index'] = line[head_dict['index']]
            examples.append(ex)
        logger.info("  {} examples".format(len(examples)))
        return examples


class HelpReader(NLIDataReader):
    """
    Data Reader for HELP
    Notice: There are some '-' gold label in the dataset, they are labeled as -1.
            There should be 5 labels; however in training set most example lacks labels, no label will also be labeld as -1

    Retrun of get_xx_examples: dict list. each example is a dict
    """
    def __init__(self):
        # self.label2id_dict = {'entailment': 0, 'neutral': 1}
        self.label2id_dict = NLI_3_LABEL
        self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
        self.data_keys = ['guid', 'pair_id', 'label_id', 'premise', 'hypothesis', 'determiner', 'monotonicity'] #,
        # "premise_length", "hypothesis_length"]



    def get_test_examples(self, data_dir, custom_file_name=None): # down
        logger.info("Read HELP set...")
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples))
        # return examples
        return self._create_examples(read_tsv(file_path), "test")

    def get_up_examples(self, data_dir, custom_file_name=None):
        logger.info("Read HELP set...")
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples), key="upward_monotone")
        # return examples
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="upward_monotone")

    def get_down_examples(self, data_dir, custom_file_name=None):
        logger.info("Read HELP set...")
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples), key="downward_monotone")
        # return examples
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="downward_monotone")


    def get_non_examples(self, data_dir, custom_file_name=None):
        logger.info("Read HELP set...")
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples), key="non_monotone")
        # return examples
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="non_monotone")


    def get_conj_examples(self, data_dir, custom_file_name=None):
        logger.info("Read HELP set...")
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples), key="conjunction")
        # return examples
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="conjunction")

    def get_disconj_examples(self, data_dir, custom_file_name=None):
        logger.info("Read HELP set...")
        # examples = []
        # for fname in ["pmb_train_v1.0.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "help", fname)), "test", start_num=len(examples), key="disjunction")
        # return examples
        file_path = os.path.join(data_dir, "help", "pmb_train_v1.0.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="disjunction")

    def get_train_examples(self, data_dir, custom_file_path=None):
        pass

    def get_dev_examples(self, data_dir, custom_file_path=None):
        pass


    # def get_labels(self):
    #     return self.label2id_dict.keys()
    #
    #
    # def label2id(self, label):
    #     tmp = label.strip()
    #     return self.label2id_dict[tmp] if tmp in self.label2id_dict.keys() else -1
    #
    #
    # def id2label(self, id):
    #     return self.id2label_dict[id]


    def _create_examples(self, lines, set_type, start_num=0, key=None):
        """Creates examples for the training and dev sets."""
        examples = []
        head_dict = {k: v for v, k in enumerate(lines[0])}

        for (i, line) in enumerate(tqdm(lines)):
            if i == 0:
                continue
            label_id = self.label2id(line[head_dict['gold_label']])

            pair_id = line[head_dict['index']].strip()
            premise = line[head_dict['ori_sentence']].strip()
            hypothesis = line[head_dict['new_sentence']].strip()
            # premise_length = len(premise)
            # hypothesis_length = len(hypothesis)
            guid = "%s-%s" % (set_type, i+start_num)
            if premise[0] == "'" and premise[-1] == "'":
                premise = premise[1:-1].strip()
            if premise[0] == '"' and premise[-1] == '"':
                premise = premise[1:-1].strip()
            if hypothesis[0] == "'" and hypothesis[-1] == "'":
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[0] == '"' and hypothesis[-1] == '"':
                hypothesis = hypothesis[1:-1].strip()
            if premise[-1] == '.':
                premise = premise[:-1].strip()
            if hypothesis[-1] == '.':
                hypothesis == hypothesis[:-1].strip()
            determiner = line[head_dict['determiner']]
            monotonicity = line[head_dict['monotonicity']]

            if key is not None and key != monotonicity:
                continue

            ex = dict()
            for k in self.data_keys:
                ex[k] = eval(k)
            if 'index' in head_dict.keys():
                ex['index'] = line[head_dict['index']]
            examples.append(ex)
        logger.info("  {} examples".format(len(examples)))
        return examples


class MedReader(NLIDataReader):
    """
    Data Reader for MED
    Notice: There are some '-' gold label in the dataset, they are labeled as -1.
            There should be 5 labels; however in training set most example lacks labels, no label will also be labeld as -1

    Retrun of get_xx_examples: dict list. each example is a dict
    """
    def __init__(self):
        # self.label2id_dict = {'entailment': 0, 'neutral': 1}
        self.label2id_dict = NLI_3_LABEL
        self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
        self.data_keys = ['guid', 'pair_id', 'label_id', 'premise', 'hypothesis', 'genre',
                          'premise_bp', 'hypothesis_bp', 'premise_p', 'hypothesis_p'] #,
        # "premise_len/gth", "hypothesis_length"]



    def get_test_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MED set...")
        # examples = []
        # for fname in ["MED.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "med", fname)), "test", start_num=len(examples))
        # return examples
        file_path = os.path.join(data_dir, "med", "MED.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test")

    def get_up_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MED set...")
        # examples = []
        # for fname in ["MED.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "med", fname)), "test", start_num=len(examples), key="upward_monotone")
        # return examples
        file_path = os.path.join(data_dir, "med", "MED.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="upward_monotone")

    def get_down_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MED set...")
        # examples = []
        # for fname in ["MED.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "med", fname)), "test", start_num=len(examples), key="downward_monotone")
        # return examples
        file_path = os.path.join(data_dir, "med", "MED.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="downward_monotone")

    def get_non_examples(self, data_dir, custom_file_name=None):
        logger.info("Read MED set...")
        # examples = []
        # for fname in ["MED.tsv"]:
        #     examples += self._create_examples(
        #         read_tsv(os.path.join(data_dir, "med", fname)), "test", start_num=len(examples), key="non_monotone")
        # return examples
        file_path = os.path.join(data_dir, "med", "MED.tsv")
        if custom_file_name is not None:
            file_path = os.path.join(data_dir, custom_file_name)
        return self._create_examples(read_tsv(file_path), "test", key="non_monotone")



    def get_train_examples(self, data_dir, custom_file_path=None):
        pass

    def get_dev_examples(self, data_dir, custom_file_path=None):
        pass

    # def get_labels(self):
    #     return self.label2id_dict.keys()
    #
    #
    # def label2id(self, label):
    #     tmp = label.strip()
    #     return self.label2id_dict[tmp] if tmp in self.label2id_dict.keys() else -1
    #
    #
    # def id2label(self, id):
    #     return self.id2label_dict[id]


    def _create_examples(self, lines, set_type, start_num=0, key=None):
        """Creates examples for the training and dev sets."""
        examples = []
        head_dict = {k: v for v, k in enumerate(lines[0])}
        for (i, line) in enumerate(tqdm(lines)):
            if i == 0:
                continue

            label_id = self.label2id(line[head_dict['gold_label']])

            pair_id = line[head_dict['pairID']].strip()
            premise = line[head_dict['sentence1']].strip()
            hypothesis = line[head_dict['sentence2']].strip()
            # premise_length = len(premise)
            # hypothesis_length = len(hypothesis)
            guid = "%s-%s" % (set_type, i+start_num)
            genre = line[head_dict['genre']].strip()
            premise_bp = head_dict['sentence1_binary_parse']
            hypothesis_bp = head_dict['sentence2_binary_parse']
            premise_p = head_dict['sentence1_parse']
            hypothesis_p = head_dict['sentence2_parse']
            if premise[0] == "'" and premise[-1] == "'":
                premise = premise[1:-1].strip()
            if premise[0] == '"' and premise[-1] == '"':
                premise = premise[1:-1].strip()
            if hypothesis[0] == "'" and hypothesis[-1] == "'":
                hypothesis = hypothesis[1:-1].strip()
            if hypothesis[0] == '"' and hypothesis[-1] == '"':
                hypothesis = hypothesis[1:-1].strip()
            if premise[-1] == '.':
                premise = premise[:-1].strip()
            if hypothesis[-1] == '.':
                hypothesis = hypothesis[:-1].strip()

            if key is not None and key not in genre:
                continue

            ex = dict()
            for k in self.data_keys:
                ex[k] = eval(k)
            if 'index' in head_dict.keys():
                ex['index'] = line[head_dict['index']]
            examples.append(ex)
        logger.info("  {} examples".format(len(examples)))
        return examples


# ======== Knowledge Base ========
class WordNet(object):
    def __init__(self, wordnet_dir, lowercase=False, remove_phrase=False):
        self.lowercase = lowercase
        self.remove_phrase = remove_phrase
        self.num_phrase = 0
        self._word2id_dict = None    # word: (synset_id.w_num)
        self._id2word_dict = None    # synset_id.w_num: (word, ss_type, sense_number, tag_count)
        self._word2full_dict = None  # word: set(synset_id.w_num.ss_type.sense_number.tag_count)
        self._full2word_dict = None # synset_id.w_num.ss_type.sense_number.tag_count: word
        self._synset2word_dict = None    # synset_id: set(word)
        self._synset2def_dict = None   # synset_id: list()
        self._synset2ex_dict = None
        self._hyper_dict = None   # sysnset_id: set(synset_id)
        self._hypo_dict = None
        self._has_ins_dict = None
        self._has_class_dict = None
        self._has_general_dict = None
        self._has_specific_dict = None
        self._sim_dict = None
        self._vgp_dict = None
        self._at_dict = None
        self._ant_dict = None    # synset_id.w_num: set(synset_id.w_num)

        self._eq_hyp_dict = None    # hypo reverse, might be same synset  # sysnset_id: set(synset_id)

        self._read_files(wordnet_dir)
        self._clean_hyp()

        # for k in self._hyper_dict.keys():
        #     if len(self._hyper_dict[k]) > 1:
        #         print(k)
        #
        # for k in self._hypo_dict.keys():
        #     if len(self._hypo_dict[k]) > 1:
        #         print(k)



    def _read_files(self, wordnet_dir):
        """
        Read WordNet files
        :param wordnet_dir: directory of wordnet files
        :return:
        """
        print("*"*20, "Start to Read WordNet", "*"*20)
        self._build_vocab(wordnet_dir)
        self._g(wordnet_dir)
        self._hyp(wordnet_dir)
        self._ins(wordnet_dir)
        self._ent(wordnet_dir)
        self._sim(wordnet_dir)
        self._vgp(wordnet_dir)
        self._at(wordnet_dir)
        self._ant(wordnet_dir)


    def _build_vocab(self, wordnet_dir):
        """
        Build WordNet Vocab from wn_s.pl
        s(synset_id, w_num, 'word', ss_type, sense_number, tag_count)
        e.g. s(100001740,1,'entity',n,1,11).
        :param wordnet_dir: directory of wordnet files
        :return:
        """
        word2id = OrderedDict() # word_id_num  word: (synset_id.w_num, synset_id.w_num, ss_type, sense_number, tag_count)
        synset2word = OrderedDict() # id_word synset_id: (word, word)
        id2word = OrderedDict() # id_num_word synset_id.w_num: (word, ss_type, sense_number, tag_count)
        word2full = OrderedDict()
        full2word = OrderedDict()
        num_phrase = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_s.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^s\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                synset_id = s[0]
                w_num = s[1]
                word = s[2][1:-1]
                # if word == 'choir':
                #     print(1)
                ss_type = s[3]
                if len(s) >= 5:
                    sense_number = s[4]
                else:
                    sense_number = 0
                if len(s) >= 6:
                    tag_count = s[5]
                else:
                    tag_count = 0

                word_id = str(synset_id) + '.' + str(w_num)
                full_id = str(synset_id) + '.' + str(w_num) + '.' + str(ss_type) + '.' \
                          + str(sense_number) + '.' + str(tag_count)
                # id_num = synset_id + '.' + w_num
                if ' ' in word:
                    num_phrase += 1
                    if self.remove_phrase:
                        continue
                    # else:
                    #     word = '_'.join(word.split())

                if self.lowercase:
                    word = word.lower()
                if word not in word2id.keys():
                    word2id[word] = [word_id]
                else:
                    word2id[word].append(word_id)

                if synset_id not in synset2word.keys():
                    synset2word[synset_id] = [word]
                else:
                    synset2word[synset_id].append(word)

                if word_id not in id2word.keys():
                    id2word[word_id] = (word, ss_type, sense_number, tag_count)
                else:
                    temp = id2word[word_id]
                    if temp[0]==word and temp[1]==ss_type and temp[2]==sense_number and temp[3]==tag_count:
                        if ' ' in word:
                            num_phrase -= 1
                        continue
                    else:
                        print("** Error: ", line)

                if word not in word2full.keys():
                    word2full[word] = [full_id]
                else:
                    word2full[word].append(full_id)

                if full_id not in full2word.keys():
                    full2word[full_id] = [word]
                else:
                    full2word[full_id].append(word)

        self._id2word_dict = id2word
        self._word2id_dict = word2id
        self._synset2word_dict = synset2word
        self._full2word_dict = full2word
        self._word2full_dict = word2full

        self.num_phrase = num_phrase
        print("-"*10, 'wn_s.pl', "-"*10)
        print('number of phrases: ', num_phrase)
        print('size of word vocab: ', len(word2id.keys()))
        print('number of synset: ', len(synset2word.keys()))
        print('number of word id: ', len(id2word.keys()))

        return


    def _g(self, wordnet_dir):
        """
        Build WordNet Def & Examples from wn_g.pl
        g(synset_id,’gloss’).
        e.g. g(100006269,'living things collectively; "the oceans are teeming with life"').
        :param wordnet_dir: directory of wordnet files
        :return:
        """
        synset2def_dict = OrderedDict()  #  synset_id: list()
        synset2ex_dict = OrderedDict()  #  synset_id: list()
        num_ex = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_g.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r"^g\((\d*),'(.*)'\)", line)
                if p is None:
                    continue
                synset_id = p[1]
                # print(line)
                pos = p[2].find('; "')
                synset2def_dict[synset_id] = p[2][:pos].split(';')
                if pos != -1:
                    synset2ex_dict[synset_id] = p[2][pos+3:-2].split('"; "')
                    num_ex += len(synset2ex_dict[synset_id])

        self._synset2def_dict = synset2def_dict
        self._synset2ex_dict = synset2ex_dict

        print("-" * 10, 'wn_g.pl', "-" * 10)
        print('number of synset def: ', len(synset2def_dict.keys()))
        print('number of synset ex: ', len(synset2ex_dict.keys()))
        print('number of examples: ', num_ex)

        return


    def _hyp(self, wordnet_dir):
        """
        Read Hyp relations from wordnet file wn_hyp.pl
        The hyp operator speciﬁes that the second synset is a hypernym of the ﬁrst synset.
        This relation holds for nouns and verbs.
        hyp(synset_id,synset_id)   (Hyponym (down), Hypernym (up) )
        e.g. hyp(100001930,100001740).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        hyper_dict = OrderedDict()  # sysnset_id: set(synset_id)
        hypo_dict = OrderedDict()  # synset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_hyp.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^hyp\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                hypo = s[0]
                hyper = s[1]
                num_rel += 1
                if hypo not in hyper_dict.keys():
                    hyper_dict[hypo] = [hyper]
                else:
                    hyper_dict[hypo].append(hyper)

                if hyper not in hypo_dict.keys():
                    hypo_dict[hyper] = [hypo]
                else:
                    hypo_dict[hyper].append(hypo)

        self._hyper_dict = hyper_dict
        self._hypo_dict = hypo_dict
        print("-" * 10, 'wn_hyp.pl', "-" * 10)
        print('number of hyp rel: ', num_rel)
        print('size of hyper dict: ', len(hyper_dict.keys()))
        print('size of hypo dict: ', len(hypo_dict.keys()))

        return


    def _ins(self, wordnet_dir):
        """
        Read ins relations from wordnet file wn_ins.pl
        The ins operator speciﬁes that the ﬁrst synset is an instance of the second synset.
        This relation holds for nouns.
        ins(synset_id,synset_id)   (instance, class)
        e.g. ins(100060548,100058743)..
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        has_ins_dict = OrderedDict()  # sysnset_id: set(synset_id)
        has_class_dict = OrderedDict()  # synset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_ins.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^ins\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                ins = s[0]
                cla = s[1]
                num_rel += 1
                if ins not in has_class_dict.keys():
                    has_class_dict[ins] = [cla]
                else:
                    has_class_dict[ins].append(cla)

                if cla not in has_ins_dict.keys():
                    has_ins_dict[cla] = [ins]
                else:
                    has_ins_dict[cla].append(ins)

        self._has_ins_dict = has_ins_dict
        self._has_class_dict = has_class_dict
        print("-" * 10, 'wn_ins.pl', "-" * 10)
        print('number of ins rel: ', num_rel)
        print('size of has_ins dict: ', len(has_ins_dict.keys()))
        print('size of has_class dict: ', len(has_class_dict.keys()))

        return


    def _ent(self, wordnet_dir):
        """
        Read ent relations from wordnet file wn_ent.pl
        The ent operator speciﬁes that the second synset is an entailment of ﬁrst synset. This relation only holds for verbs.
        ent(synset_id,synset_id)   (general, specific )
        e.g. ent(200001740,200005041).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        has_general_dict = OrderedDict()  # sysnset_id: set(synset_id)
        has_specific_dict = OrderedDict()  # synset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_ent.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^ent\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                gen = s[0]
                spe = s[1]
                num_rel += 1
                if gen not in has_specific_dict.keys():
                    has_specific_dict[gen] = [spe]
                else:
                    has_specific_dict[gen].append(spe)

                if spe not in has_general_dict.keys():
                    has_general_dict[spe] = [gen]
                else:
                    has_general_dict[spe].append(gen)

        self._has_general_dict = has_general_dict
        self._has_specific_dict = has_specific_dict
        print("-" * 10, 'wn_ent.pl', "-" * 10)
        print('number of ent rel: ', num_rel)
        print('size of has_general dict: ', len(has_general_dict.keys()))
        print('size of has_specific dict: ', len(has_specific_dict.keys()))

        return


    def _sim(self, wordnet_dir):
        """
        Read sim relations from wordnet file wn_sim.pl
        The sim operator speciﬁes that the second synset is similar in meaning to the ﬁrst synset.
        This means that the second synset is a satellite the ﬁrst synset, which is the cluster head.
        This relation only holds for adjective synsets contained in adjective clusters.
        sim(synset_id, synset_id)
        e.g. sim(300003356,300003553).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        sim_dict = OrderedDict()  # sysnset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_sim.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^sim\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                s0 = s[0]
                s1 = s[1]
                num_rel += 1
                if s0 not in sim_dict.keys():
                    sim_dict[s0] = [s1]
                else:
                    if s1 not in sim_dict[s0]:
                        sim_dict[s0].append(s1)

                if s1 not in sim_dict.keys():
                    sim_dict[s1] = [s0]
                else:
                    if s0 not in sim_dict[s1]:
                        sim_dict[s1].append(s0)

        self._sim_dict = sim_dict
        print("-" * 10, 'wn_sim.pl', "-" * 10)
        print('number of sim rel: ', num_rel)
        print('size of sim dict: ', len(sim_dict.keys()))

        return


    def _vgp(self, wordnet_dir):
        """
        Read vgp relations from wordnet file wn_vgp.pl
        The vgp operator speciﬁes verb synsets that are similar in meaning and should be grouped together
        when displayed in response to a grouped synset search.
        vgp(synset_id,w_num,synset_id,w_num). (w_num are all set to 0 in the file)
        e.g. vgp(200001740,0,200002325,0).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        vgp_dict = OrderedDict()  # sysnset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_vgp.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^vgp\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                s0 = s[0]
                s1 = s[2]
                num_rel += 1
                if s0 not in vgp_dict.keys():
                    vgp_dict[s0] = [s1]
                else:
                    vgp_dict[s0].append(s1)

                if s1 not in vgp_dict.keys():
                    vgp_dict[s1] = [s0]
                else:
                    vgp_dict[s1].append(s0)

        self._vgp_dict = vgp_dict
        print("-" * 10, 'wn_vgp.pl', "-" * 10)
        print('number of vgp rel: ', num_rel)
        print('size of vgp dict: ', len(vgp_dict.keys()))

        return


    def _at(self, wordnet_dir):
        """
        Read at relations from wordnet file wn_at.pl
        The at operator deﬁnes the attribute relation between noun and adjective synset pairs in which
        the adjective is a value of the noun.
        at(synset_id,synset_id).
        e.g. at(100033615,302295998).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        at_dict = OrderedDict()  # sysnset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_at.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^at\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                s0 = s[0]
                s1 = s[1]
                num_rel += 1
                if s0 not in at_dict.keys():
                    at_dict[s0] = [s1]
                else:
                    at_dict[s0].append(s1)

                if s1 not in at_dict.keys():
                    at_dict[s1] = [s0]
                else:
                    at_dict[s1].append(s0)

        self._at_dict = at_dict
        print("-" * 10, 'wn_at.pl', "-" * 10)
        print('number of at rel: ', num_rel)
        print('size of at dict: ', len(at_dict.keys()))

        return


    def _ant(self, wordnet_dir):
        """
        Read ant relations from wordnet file wn_ant.pl
        The ant operator speciﬁes antonymous words.
        This is a lexical relation that holds for all syntactic categories.
        ant(synset_id,w_num,synset_id,w_num).
        e.g. ant(100019128,1,100021939,1).
        :param wordnet_dir: directory of wordnet files
        :return:
        """

        ant_dict = OrderedDict()  # sysnset_id: set(synset_id)
        num_rel = 0

        synset_path = os.path.join(wordnet_dir, 'prolog', 'wn_ant.pl')
        with open(synset_path, 'r') as f:
            for line in f:
                p = re.match(r'^ant\((.*)\)', line)
                if p is None:
                    continue
                s = p[1].split(',')
                # print(line)
                s0 = s[0] + '.' + s[1]
                s1 = s[2] + '.' + s[3]
                num_rel += 1
                if s0 not in ant_dict.keys():
                    ant_dict[s0] = [s1]
                else:
                    ant_dict[s0].append(s1)

                if s1 not in ant_dict.keys():
                    ant_dict[s1] = [s0]
                else:
                    ant_dict[s1].append(s0)

        self._ant_dict = ant_dict
        print("-" * 10, 'wn_ant.pl', "-" * 10)
        print('number of ant rel: ', num_rel)
        print('size of ant dict: ', len(ant_dict.keys()))

        return


    def id2word(self, word_id):
        """
        synset_id.w_num => word
        If not found, return None
        :param word_id: synset_id.w_num
        :return: word
        """
        return self._id2word_dict[word_id][0] if word_id in self._id2word_dict.keys() else None


    def word2fullids(self, word, pos=None):
        """
        word => set(synset_id.w_num)
        If not found, return None
        :param word: word
        :return: word_id set
        """
        ids = self._word2full_dict[word].copy() if word in self._word2full_dict.keys() else None
        if pos is not None and ids is not None:
            if pos == 'a':
                p = ['a', 's']
            else:
                p = [pos]
            tmp = [i for i in ids if i.split('.')[2] in p]
            if len(tmp) < 1:
                tmp = ids
            ids = tmp
        if ids is not None:
            # order by count
            ids = sorted(ids, key=lambda x: int(x.split('.')[-1]), reverse=True)
        return ids


    def word2ids(self, word, pos=None):
        """
        word => set(synset_id.w_num)
        If not found, return None
        :param word: word
        :return: word_id set
        """
        ids = self._word2full_dict[word].copy() if word in self._word2full_dict.keys() else None
        if pos is not None and ids is not None:
            if pos == 'a':
                p = ['a', 's']
            else:
                p = [pos]
            tmp = [i for i in ids if i.split('.')[2] in p]
            if len(tmp) < 1:
                tmp = ids
            ids = tmp
        if ids is not None:
            # order by count
            ids = sorted(ids, key=lambda x: int(x.split('.')[-1]), reverse=True)
            ids = [s.split('.')[0]+'.'+s.split('.')[1] for s in ids]
        return ids


    def synset2word(self, synset_id, freq=True):
        """
        synset_id => set(word)
        If not found, return None
        :param synset_id:
        :return:
        """
        s = self._synset2word_dict[synset_id].copy() if synset_id in self._synset2word_dict.keys() else None
        if s is not None and freq:
            word_list = []
            for w in s:
                full_id = self.word2fullids(w)
                this_id = [x for i, x in enumerate(full_id) if x.find(synset_id) != -1][0]
                if int(this_id.split('.')[-1]) > 0:
                    word_list.append(w)
            s = word_list
        return s



    def synset2def(self, synset_id):
        """
        synset_id => definition
        If not found, return null list
        :param synset_id:
        :return:
        """
        return self._synset2def_dict[synset_id].copy() if synset_id in self._synset2def_dict.keys() else None


    def synset2ex(self, synset_id):
        """
        synset_id => examples
        If not found, return None
        :param synset_id:
        :return:
        """
        return self._synset2ex_dict[synset_id].copy() if synset_id in self._synset2ex_dict.keys() else None


    def _clean_hyp(self):
        """
        Clean the hyp rel
        If the word pair (i, j) and (j, i) both in hyp rel, delete those pairs from hyp rel.
        :return:
        """
        num_rev_hyp = 0
        eq_hyp_dict = OrderedDict()
        for i in list(self._hypo_dict.keys()):
            j_set = self._hypo_dict[i]
            for j in j_set:
                if j in self._hypo_dict.keys():
                    jj_set = self._hypo_dict[j]
                    if i in jj_set:
                        num_rev_hyp += 1
                        # Save this rel
                        if i not in eq_hyp_dict.keys():
                            eq_hyp_dict[i] = [j]
                        else:
                            eq_hyp_dict[i].append(j)
                        if j not in eq_hyp_dict.keys():
                            eq_hyp_dict[j] = [i]
                        else:
                            eq_hyp_dict[j].append(i)

                        # del (j,i)
                        if len(jj_set) == 1:
                            self._hypo_dict.pop(j)
                        else:
                            self._hypo_dict[j] = list(set(self._hypo_dict[j])-set([i]))

                        if len(self._hyper_dict[j]) == 1:
                            self._hyper_dict.pop(j)
                        else:
                            self._hyper_dict[j] = list(set(self._hyper_dict[j])-set([i]))

                        # del (i,j)
                        if len(j_set) == 1:
                            self._hypo_dict.pop(i)
                        else:
                            self._hypo_dict[i] = list(set(self._hypo_dict[i]) - set([j]))

                        if len(self._hyper_dict[i]) == 1:
                            self._hyper_dict.pop(i)
                        else:
                            self._hyper_dict[i] = list(set(self._hyper_dict[i]) - set([j]))


        self._eq_hyp_dict = eq_hyp_dict
        print("-" * 10, 'clean_hyp', "-" * 10)
        print('number of reverse hyp rel: ', num_rev_hyp)

        return


    def id2synset(self, wordid):

        return wordid.split('.')[0]


    def get_sim(self, synset_id):
        return self._sim_dict[synset_id].copy() if synset_id in self._sim_dict.keys() else []

    def get_vgp(self, synset_id):
        return self._vgp_dict[synset_id].copy() if synset_id in self._vgp_dict.keys() else []

    def get_at(self, synset_id):
        return self._at_dict[synset_id].copy() if synset_id in self._at_dict.keys() else []

    def get_ant(self, word_id):
        return self._ant_dict[word_id].copy() if word_id in self._ant_dict.keys() else []

    def get_hyper(self, synset_id):
        return self._hyper_dict[synset_id].copy() if synset_id in self._hyper_dict.keys() else []

    def get_hypo(self, synset_id):
        return self._hypo_dict[synset_id].copy() if synset_id in self._hypo_dict.keys() else []

    def get_general(self, synset_id):
        return self._has_general_dict[synset_id].copy() if synset_id in self._has_general_dict.keys() else []

    def get_specific(self, synset_id):
        return self._has_specific_dict[synset_id].copy() if synset_id in self._has_specific_dict.keys() else []

    def get_ins(self, synset_id):
        return self._has_ins_dict[synset_id].copy() if synset_id in self._has_ins_dict.keys() else []

    def get_class(self, synset_id):
        return self._has_class_dict[synset_id].copy() if synset_id in self._has_class_dict.keys() else []

    def get_example(self, synset_id):
        return self._synset2ex_dict[synset_id].copy() if synset_id in self._synset2ex_dict.keys() else []

class NatlogKnowledge(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def __init__(self):
        pass

    @abc.abstractmethod
    def get_eq(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_ent_f(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_ent_r(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_neg(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_alt(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_cov(self, word, pos=None):
        pass

    @abc.abstractmethod
    def get_ind(self, word, pos=None):
        pass


class NatlogWordNet(NatlogKnowledge):
    def __init__(self, wordnet_dir, lm_model, device):
        self.wordnet = WordNet(wordnet_dir)
        self.lm_model = lm_model
        self.device = device

    def get_synset_id(self, word, sentence, word_idx, pos=None):
        full_id = self.wordnet.word2fullids(word, pos)
        examples = [self.wordnet.get_example(i) for i in full_id.split('.')[0]]



    def get_eq(self, word, pos=None):
        """
        4 type (1. same synset_id, 2. sim, 3. vgp, 4. at)
        :param word:
        :return:
        """

        eq_list = list()
        # Find synset_id
        full_id = self.wordnet.word2fullids(word, pos)
        if full_id is None:
            return eq_list
        else:
            large_id = [i for i in full_id if int(i.split('.')[-1])>0]
            if len(large_id) > 0:
                # if len(large_id) > 1:
                #     num_tag = [int(i.split('.')[-1]) for i in large_id]
                #     num_tag = sorted(num_tag, reverse=True)
                #     if num_tag[0] > 500:
                #         large_id = [large_id[0]]
                #     else:
                #         cut = int(np.ceil(len(num_tag) *2/3))
                #         cut_tag = num_tag[cut]
                #         large_id = [i for i in full_id if int(i.split('.')[-1])>cut_tag]
                # full_id = large_id
                num_tag = max([int(i.split('.')[-1]) for i in large_id])
                full_id = [i for i in large_id if int(i.split('.')[-1]) == num_tag]
            else:
                full_id = [full_id[0]]
        synset_id_list = [self.wordnet.id2synset(i) for i in full_id]


        # 1. same synset_id
        word_list = [self.wordnet.synset2word(syn_id) for syn_id in synset_id_list]
        word_list = list(set(itertools.chain(*word_list)))
        if len(word_list) > 0:
            # word_list = [w for w in word_list if re.search('\d', w) is None]
            if word in word_list:
                word_list.remove(word)
            eq_list += word_list.copy()
            # print("eq1 has {} rels".format(len(word_list)))

        # 2. sim only for adj
        if pos == 'a':
            sim_list = [self.wordnet.get_sim(syn_id) for syn_id in synset_id_list]
            sim_list = list(itertools.chain(*sim_list))
            if len(sim_list) > 0:
                word_list = [self.wordnet.synset2word(s) for s in sim_list]
                word_list = list(set(itertools.chain(*word_list)))
                if word in word_list:
                    word_list.remove(word)
                eq_list += word_list.copy()
                # print("eq2 has {} rels".format(len(word_list)))

        # 3. vgp only for v
        if pos == 'v':
            vgp_list = [self.wordnet.get_vgp(syn_id) for syn_id in synset_id_list]
            vgp_list = list(itertools.chain(*vgp_list))
            if len(vgp_list) > 0:
                word_list = [self.wordnet.synset2word(s) for s in vgp_list]
                word_list = list(set(itertools.chain(*word_list)))
                if word in word_list:
                    word_list.remove(word)
                eq_list += word_list.copy()
                # print("eq3 has {} rels".format(len(word_list)))

        # 4. at for n and adj
        if pos in ['n', 'a']:
            at_list = [self.wordnet.get_at(syn_id) for syn_id in synset_id_list]
            at_list = list(itertools.chain(*at_list))
            if len(at_list) > 0:
                word_list = [self.wordnet.synset2word(s) for s in at_list]
                word_list = list(set(itertools.chain(*word_list)))
                if word in word_list:
                    word_list.remove(word)
                eq_list += word_list.copy()
                # print("eq4 has {} rels".format(len(word_list)))

        eq_list = list(set(eq_list))

        return eq_list


    def get_ent_f(self, word, pos=None, stack=3):
        """
        Generate entailment data (recursively) and save them in the output_dir
        3 type (1. hyp, 2. ins, 3. ent)
        :param word:
        :param pos:
        :return:
        """
        ent_f_list = list()
        # Find synset_id
        full_id = self.wordnet.word2fullids(word, pos)
        if full_id is None:
            return ent_f_list
        else:
            large_id = [i for i in full_id if int(i.split('.')[-1])>0]
            if len(large_id) > 0:
                # if len(large_id) > 1:
                #     num_tag = [int(i.split('.')[-1]) for i in large_id]
                #     num_tag = sorted(num_tag, reverse=True)
                #     if num_tag[0] > 500:
                #         large_id = [large_id[0]]
                #     else:
                #         cut = int(np.ceil(len(num_tag) *2/3))
                #         cut_tag = num_tag[cut]
                #         large_id = [i for i in full_id if int(i.split('.')[-1])>cut_tag]
                # full_id = large_id
                num_tag = max([int(i.split('.')[-1]) for i in large_id])
                full_id = [i for i in large_id if int(i.split('.')[-1]) == num_tag]
            else:
                full_id = [full_id[0]]
        synset_id_list = [self.wordnet.id2synset(i) for i in full_id][0:2]

        # 1. hyp(a,b) -> hyper_dict[a] = b -> a<b
        input_ids = synset_id_list.copy()
        output_ids = list()
        for n in range(stack):
            hyper_ids = list()
            for id in input_ids:
                hyper_id = self.wordnet.get_hyper(id)
                hyper_ids += hyper_id.copy()
            input_ids = hyper_ids.copy()
            output_ids += hyper_ids.copy()
        output_ids = list(set(output_ids))
        word_list = [self.wordnet.synset2word(s) for s in output_ids]
        word_list = list(set(itertools.chain(*word_list)))
        ent_f_list += word_list.copy()


        # 2. ins(a,b) -> has_class_dict[a] = b -> a < b
        input_ids = synset_id_list.copy()
        output_ids = list()
        for n in range(stack):
            hyper_ids = list()
            for id in input_ids:
                hyper_id = self.wordnet.get_class(id)
                hyper_ids += hyper_id.copy()
            input_ids = hyper_ids.copy()
            output_ids += hyper_ids.copy()
        output_ids = list(set(output_ids))
        word_list = [self.wordnet.synset2word(s) for s in output_ids]
        word_list = list(set(itertools.chain(*word_list)))
        ent_f_list += word_list.copy()


        # 3. ent(b,a) -> has_general_dict[a] = b -> a < b
        if pos == 'v':
            input_ids = synset_id_list.copy()
            output_ids = list()
            for n in range(stack):
                hyper_ids = list()
                for id in input_ids:
                    hyper_id = self.wordnet.get_general(id)
                    hyper_ids += hyper_id.copy()
                input_ids = hyper_ids.copy()
                output_ids += hyper_ids.copy()
            output_ids = list(set(output_ids))
            word_list = [self.wordnet.synset2word(s) for s in output_ids]
            word_list = list(set(itertools.chain(*word_list)))
            ent_f_list += word_list.copy()

        ent_f_list = list(set(ent_f_list))

        return ent_f_list


    def get_ent_r(self, word, pos=None, stack=3):
        ent_r_list = list()
        # Find synset_id
        full_id = self.wordnet.word2fullids(word, pos)
        if full_id is None:
            return ent_r_list
        else:
            large_id = [i for i in full_id if int(i.split('.')[-1])>0]
            if len(large_id) > 0:
                # if len(large_id) > 1:
                #     num_tag = [int(i.split('.')[-1]) for i in large_id]
                #     num_tag = sorted(num_tag, reverse=True)
                #     if num_tag[0] > 500:
                #         large_id = [large_id[0]]
                #     else:
                #         cut = int(np.ceil(len(num_tag) *2/3))
                #         cut_tag = num_tag[cut]
                #         large_id = [i for i in full_id if int(i.split('.')[-1])>cut_tag]
                # full_id = large_id
                num_tag = max([int(i.split('.')[-1]) for i in large_id])
                full_id = [i for i in large_id if int(i.split('.')[-1]) == num_tag]
            else:
                full_id = [full_id[0]]
        synset_id_list = [self.wordnet.id2synset(i) for i in full_id][0:4]

        # 1. hyp(a,b) -> hyper_dict[a] = b -> a<b
        input_ids = synset_id_list.copy()
        output_ids = list()
        for n in range(stack):
            hypo_ids = list()
            for id in input_ids:
                hypo_id = self.wordnet.get_hypo(id)
                hypo_ids += hypo_id.copy()
            input_ids = hypo_ids.copy()
            output_ids += hypo_ids.copy()
        output_ids = list(set(output_ids))
        word_list = [self.wordnet.synset2word(s) for s in output_ids]
        word_list = list(set(itertools.chain(*word_list)))
        ent_r_list += word_list.copy()


        # 2. ins(a,b) -> has_class_dict[a] = b -> a < b
        input_ids = synset_id_list.copy()
        output_ids = list()
        for n in range(stack):
            hypo_ids = list()
            for id in input_ids:
                hypo_id = self.wordnet.get_ins(id)
                hypo_ids += hypo_id.copy()
            input_ids = hypo_ids.copy()
            output_ids += hypo_ids.copy()
        output_ids = list(set(output_ids))
        word_list = [self.wordnet.synset2word(s) for s in output_ids]
        word_list = list(set(itertools.chain(*word_list)))
        ent_r_list += word_list.copy()


        # 3. ent(b,a) -> has_general_dict[a] = b -> a < b
        if pos == 'v':
            input_ids = synset_id_list.copy()
            output_ids = list()
            for n in range(stack):
                hypo_ids = list()
                for id in input_ids:
                    hypo_id = self.wordnet.get_specific(id)
                    hypo_ids += hypo_id.copy()
                input_ids = hypo_ids.copy()
                output_ids += hypo_ids.copy()
            output_ids = list(set(output_ids))
            word_list = [self.wordnet.synset2word(s) for s in output_ids]
            word_list = list(set(itertools.chain(*word_list)))
            ent_r_list += word_list.copy()

        ent_r_list = list(set(ent_r_list))

        return ent_r_list


    def get_neg(self, word, pos=None):
        """
        Generate negation data and save them in the output_dif
        1 type (ant)
        :param word:
        :param pos:
        :return:
        """
        neg_list = list()
        # Find word_id
        full_id = self.wordnet.word2fullids(word, pos)
        if full_id is None:
            return neg_list
        else:
            large_id = [i for i in full_id if int(i.split('.')[-1])>0]
            if len(large_id) > 0:
                # if len(large_id) > 1:
                #     num_tag = [int(i.split('.')[-1]) for i in large_id]
                #     num_tag = sorted(num_tag, reverse=True)
                #     if num_tag[0] > 500:
                #         large_id = [large_id[0]]
                #     else:
                #         cut = int(np.ceil(len(num_tag) *2/3))
                #         cut_tag = num_tag[cut]
                #         large_id = [i for i in full_id if int(i.split('.')[-1])>cut_tag]
                # full_id = large_id
                num_tag = max([int(i.split('.')[-1]) for i in large_id])
                full_id = [i for i in large_id if int(i.split('.')[-1]) == num_tag]
            else:
                full_id = [full_id[0]]
        word_id_list = [s.split('.')[0]+'.'+s.split('.')[1] for s in full_id][0:4]

        # 1. ant(a, b) => a^b
        word_list = [self.wordnet.get_ant(w) for w in word_id_list]
        word_list = list(itertools.chain(*word_list))
        if len(word_list) > 0:
            word_list = [self.wordnet.id2word(s) for s in word_list]
            # word_list = list(set(itertools.chain(*word_list)))
            word_list = [i for i in list(set(word_list)) if i is not None]
            if word in word_list:
                word_list.remove(word)
            neg_list += word_list.copy()

        return neg_list


    def get_alt(self, word, pos=None, stack=1):
        """
        Find hyper synset then find its hypo
        :param word:
        :param pos:
        :return:
        """
        ent_f_list = list()
        # Find synset_id
        full_id = self.wordnet.word2fullids(word, pos)
        if full_id is None:
            return ent_f_list
        else:
            large_id = [i for i in full_id if int(i.split('.')[-1])>0]
            if len(large_id) > 0:
                # if len(large_id) > 1:
                #     num_tag = [int(i.split('.')[-1]) for i in large_id]
                #     num_tag = sorted(num_tag, reverse=True)
                #     if num_tag[0] > 500:
                #         large_id = [large_id[0]]
                #     else:
                #         cut = int(np.ceil(len(num_tag) *2/3))
                #         cut_tag = num_tag[cut]
                #         large_id = [i for i in full_id if int(i.split('.')[-1])>cut_tag]
                # full_id = large_id
                num_tag = max([int(i.split('.')[-1]) for i in large_id])
                full_id = [i for i in large_id if int(i.split('.')[-1]) == num_tag]
            else:
                full_id = [full_id[0]]
        synset_id_list = [self.wordnet.id2synset(i) for i in full_id][0:4]

        # Get Hyper synset_id
        # 1. hyp(a,b) -> hyper_dict[a] = b -> a<b
        input_ids = synset_id_list.copy()
        output_ids = list()
        for n in range(stack):
            hyper_ids = list()
            for id in input_ids:
                hyper_id = self.wordnet.get_hyper(id)
                hyper_ids += hyper_id.copy()
            input_ids = hyper_ids.copy()
            output_ids += hyper_ids.copy()

        # 2. ins(a,b) -> has_class_dict[a] = b -> a < b
        input_ids = synset_id_list.copy()
        for n in range(stack):
            hyper_ids = list()
            for id in input_ids:
                hyper_id = self.wordnet.get_class(id)
                hyper_ids += hyper_id.copy()
            input_ids = hyper_ids.copy()
            output_ids += hyper_ids.copy()

        # 3. ent(b,a) -> has_general_dict[a] = b -> a < b
        if pos == 'v':
            input_ids = synset_id_list.copy()
            for n in range(stack):
                hyper_ids = list()
                for id in input_ids:
                    hyper_id = self.wordnet.get_general(id)
                    hyper_ids += hyper_id.copy()
                input_ids = hyper_ids.copy()
                output_ids += hyper_ids.copy()

        hyper_ids = list(set(output_ids))

        # Get hypo synset_ids
        # 1. hyp(a,b) -> hyper_dict[a] = b -> a<b
        input_ids = hyper_ids.copy()
        output_ids = list()
        for n in range(stack):
            hypo_ids = list()
            for id in input_ids:
                hypo_id = self.wordnet.get_hypo(id)
                hypo_ids += list(set(hypo_id) - set(hyper_ids) - set(synset_id_list))
            input_ids = hypo_ids.copy()
            output_ids += hypo_ids.copy()

        # 2. ins(a,b) -> has_class_dict[a] = b -> a < b
        input_ids = hyper_ids.copy()
        for n in range(stack):
            hypo_ids = list()
            for id in input_ids:
                hypo_id = self.wordnet.get_ins(id)
                hypo_ids += list(set(hypo_id) - set(hyper_ids) - set(synset_id_list))
            input_ids = hypo_ids.copy()
            output_ids += hypo_ids.copy()

        # 3. ent(b,a) -> has_general_dict[a] = b -> a < b
        if pos == 'v':
            input_ids = hyper_ids.copy()
            for n in range(stack):
                hypo_ids = list()
                for id in input_ids:
                    hypo_id = self.wordnet.get_specific(id)
                    hypo_ids += list(set(hypo_id) - set(hyper_ids) - set(synset_id_list))
                input_ids = hypo_ids.copy()
                output_ids += hypo_ids.copy()

        alt_ids = list(set(output_ids))
        alt_ids = [self.wordnet.synset2word(s) for s in alt_ids]
        alt_ids = list(set(itertools.chain(*alt_ids)))

        return alt_ids



    def get_cov(self, word, pos=None):
        pass


    def get_ind(self, word, pos=None):
        pass







# # ======== DataPreprocessor ========
# class DataPreprocessor(metaclass=abc.ABCMeta):
#     """ Preprocessor: Transform Data into Features """
#     def __init__(self, label2id_dict, drop_unk_samples=True):
#         # self.do_lower_case = do_lower_case
#         self.drop_unk_samples = drop_unk_samples
#         # self.reader = reader
#         self.label2id_dict = label2id_dict
#         self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
#         # raise NotImplementedError
#
#     @abc.abstractmethod
#     def _preprocess_and_save(self, data, cached_examples_dir, **kwargs):
#
#         index = dict()
#         index['guids'] = []
#         index['feafile_name'] = []
#         index['offset'] = []
#         index['label_ids'] = []
#
#         self._save_index(cached_examples_dir, index)
#         return
#
#     def preprocess(self, reader, data_dir, cache_dir, stage, overwrite, **kwargs):
#         assert stage in ["train", 'dev', 'test']
#         cached_examples_dir = os.path.join(cache_dir, "cached_{stage}_preprocess".format(stage=stage))
#         self._preprocess(reader, data_dir, cached_examples_dir, stage, overwrite, **kwargs)
#         return cached_examples_dir
#
#     def _save_index(self, cached_examples_dir, index):
#         logger.info("  >> Saving features into cached dir %s", cached_examples_dir)
#         with open(os.path.join(cached_examples_dir, "index"), 'w') as f:
#             f.write(str(self.label2id_dict) + "\n")
#             for i in range(len(index["guids"])):
#                 f.write(index["guids"][i] + "\t" + index['feafile_name'][i] + "\t" +
#                         str(index['offset'][i]) + "\t" + str(index["label_ids"][i]) + "\n")
#         return
#
#     def _preprocess(self, reader, data_dir, cached_examples_dir, stage, overwrite, **kwargs):
#         if overwrite and os.path.exists(cached_examples_dir):
#             shutil.rmtree(cached_examples_dir)
#
#         if os.path.exists(cached_examples_dir) and not overwrite:
#             logger.info("Loading examples from cached dir %s", cached_examples_dir)
#         else:
#             os.mkdir(cached_examples_dir)
#             logger.info("  >> Preprocess {} data...".format(stage))
#             if stage == "train":
#                 data = reader.get_train_examples(data_dir)
#             elif stage == "dev":
#                 data = reader.get_dev_examples(data_dir)
#             elif stage == "test":
#                 data = reader.get_test_examples(data_dir)
#             elif stage == 'all':
#                 data = reader.get_train_examples(data_dir) + reader.get_dev_examples(data_dir) + reader.get_test_examples(data_dir)
#             else:
#                 data = eval("reader.get_" + stage + "_examples(data_dir)")
#
#             self._preprocess_and_save(data, cached_examples_dir, **kwargs)
#             return
#
#
# class DataAllPreprocessor(DataPreprocessor):
#     """ Preprocessor: Transform Data into Features """
#     def __init__(self, reader, feature_keys, drop_unk_samples=True):
#         # self.do_lower_case = do_lower_case
#         self.drop_unk_samples = drop_unk_samples
#         self.reader = reader
#         self.label2id_dict = self.reader.label2id_dict
#         self.id2label_dict = self.reader.id2label_dict
#         self.feature_keys = feature_keys
#
#     def preprocess(self, data_dir, cache_dir, stage, overwrite, **kwargs):
#         assert stage in ["train", 'dev', 'test']
#         cached_examples_dir = os.path.join(cache_dir, "cached_{stage}_preprocess".format(stage=stage))
#         self._preprocess(data_dir, cached_examples_dir, stage, overwrite, **kwargs)
#         return cached_examples_dir
#
#     def _preprocess_and_save(self, data, cached_examples_dir, **kwargs):    # 100000
#         index = dict()
#         index['guids'] = []
#         index['feafile_name'] = []
#         index['offset'] = []
#         index['label_ids'] = []
#         feafile_name = "fea"
#
#         output = dict()
#         for key in self.feature_keys:
#             output[key] = list()
#
#         for ex in tqdm(data):
#             this_output = self._data2feature(ex)
#             if len(this_output) == 0:
#                 continue
#             for key in self.feature_keys:
#                 output[key].append(this_output[key])
#
#         output = self._fea2tensor(output)
#
#         index["guids"] = output["guids"]
#         index['feafile_name'] = [feafile_name] * len(index["guids"])
#         index['offset'] = list(range(len(index["guids"])))
#         index["label_ids"] = output["label_ids"].numpy()
#
#         torch.save(output, os.path.join(cached_examples_dir, feafile_name))
#         self._save_index(cached_examples_dir, index)
#         return
#
#     def _data2feature(self, data, **kwargs):
#         """ Transform one data to feature dict. Should contain `guids` and `label_ids` """
#         raise NotImplementedError
#
#     def _fea2tensor(self, fea):
#         """ Transform feature into tensor """
#         raise NotImplementedError
#
#
# class SnliPreprocessor(DataAllPreprocessor):
#     def __init__(self, label2id_dict, vocab_path, tokenizer, del_delim=False, drop_unk_samples=True):
#     # def __init__(self, label2id_dict, vocab_path, do_lower_case=False, del_delim=False, drop_unk_samples=True):
#     #     self.do_lower_case = do_lower_case
#         self.drop_unk_samples = drop_unk_samples
#         # self.max_length = max_length
#         # self.reader = reader
#         self.label2id_dict = label2id_dict
#         self.id2label_dict = {id: label for label, id in self.label2id_dict.items()}
#         # self.vocab_size = max(self.word2id.values()) + 1
#         self.del_delim = del_delim
#
#         self.word2id, self.id2word = load_vocab(vocab_path)
#
#
#         self.feature_keys = ['guids', 'pair_id', 'label_ids', 'several_labels',
#                              'premise', 'premise_bp', 'premise_p',
#                              'hypothesis', 'hypothesis_bp', 'hypothesis_p',
#                              "p_tokens", "p_token_ids", "p_length",
#                              "h_tokens", "h_token_ids", "h_length"]
#         # self.tokenizer = StanfordTokenizer(self.do_lower_case)
#         self.tokenizer = tokenizer
#
#     def _data2feature(self, data):
#         # preprocess
#         if self.drop_unk_samples and data["gold_label_id"] not in self.id2label_dict.keys():
#             return dict()
#         # Translation tables to remove parentheses from strings.
#         parentheses_table = str.maketrans({"(": None, ")": None})
#
#         this_output = data
#         this_output["premise"] = this_output["premise"].translate(parentheses_table)
#         this_output["hypothesis"] = this_output["hypothesis"].translate(parentheses_table)
#
#         if self.del_delim:
#             delim_table = str.maketrans({".": " "})
#             this_output["premise"] = this_output["premise"].translate(delim_table)
#             this_output["hypothesis"] = this_output["hypothesis"].translate(delim_table)
#
#         this_output["several_labels"] = tuple(this_output["several_labels"])
#
#         this_output["p_tokens"] = self.tokenizer.tokenize(this_output["premise"])
#         this_output["p_length"] = len(this_output["p_tokens"])
#         this_output["h_tokens"] = self.tokenizer.tokenize(this_output["hypothesis"])
#         this_output["h_length"] = len(this_output["h_tokens"])
#
#         this_output["p_token_ids"] = torch.tensor(find_sentence_ids(self.word2id, this_output["p_tokens"]), dtype=int)
#         this_output["h_token_ids"] = torch.tensor(find_sentence_ids(self.word2id, this_output["h_tokens"]), dtype=int)
#
#         this_output["guids"] = this_output["guid"]
#         this_output["label_ids"] = this_output["gold_label_id"]
#         this_output.pop("guid")
#         this_output.pop("gold_label_id")
#         return this_output
#
#     def _fea2tensor(self, fea):
#         fea["p_token_ids"] = torch.nn.utils.rnn.pad_sequence(fea["p_token_ids"],
#                                                              batch_first=True,
#                                                              padding_value=self.word2id["[PAD]"])
#         fea["h_token_ids"] = torch.nn.utils.rnn.pad_sequence(fea["h_token_ids"],
#                                                              batch_first=True,
#                                                              padding_value=self.word2id["[PAD]"])
#         fea["p_length"] = torch.tensor(fea["p_length"], dtype=int)
#         fea["h_length"] = torch.tensor(fea["h_length"], dtype=int)
#         fea["label_ids"] = torch.tensor(fea["label_ids"], dtype=torch.long)
#         return fea
#
#     def preprocess(self, reader, data_dir, cache_dir, stage, overwrite, **kwargs):
#         assert stage in ["train", 'dev', 'test']
#         cached_examples_dir = os.path.join(cache_dir, "cached_{stage}_snli_preprocess_{size}_{lower}".format(
#             stage=stage, size=len(self.id2word.keys()), lower=self.do_lower_case))
#         self._preprocess(reader, data_dir, cached_examples_dir, stage, overwrite, **kwargs)
#         return cached_examples_dir
#
#     def preprocess_one_sample(self, premise, hypothesis):
#         tmp = self.drop_unk_samples
#         self.drop_unk_samples = False
#         sample = {
#             'guid': '',
#             'pair_id': '',
#             'gold_label_id': -1,
#             'several_labels': [],
#             'premise': premise,
#             'premise_bp': "",
#             'premise_p': "",
#             'hypothesis': hypothesis,
#             'hypothesis_bp': "",
#             'hypothesis_p': ""
#         }
#         fea = self._data2feature(sample)
#         fea["p_length"] = torch.tensor(fea["p_length"], dtype=int)
#         fea["h_length"] = torch.tensor(fea["h_length"], dtype=int)
#         self.drop_unk_samples = tmp
#         return fea

def count_length(examples):
    p = []
    h = []
    for ex in examples:
        lp = len(ex['premise'].split())
        p.append(lp)

        lh = len(ex['hypothesis'].split())
        h.append(lh)

    p.sort()
    h.sort()
    num = len(examples)
    maxp = p[-1]
    maxh = h[-1]
    avgp = sum(p)/num
    avgh = sum(h)/num
    mainnum = int(num*0.95)
    mainp = p[mainnum]
    mainh = h[mainnum]
    return mainp, maxp, avgp, mainh, maxh, avgh

if __name__ == '__main__':
    # from config import *
    #
    # snlireader = SnliReader()
    # snli_train = snlireader.get_train_examples(SNLI_DIR)
    # snli_dev = snlireader.get_dev_examples(SNLI_DIR)
    # snli_test = snlireader.get_test_examples(SNLI_DIR)
    # print("****Snli*****\n")
    # print("train: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(snli_train)))
    # print("dev: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(snli_dev)))
    # print("test: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(snli_test)))
    #
    # mnlireader = MnliReader()
    # mnli_train = mnlireader.get_train_examples(MNLI_DIR)
    # mnli_dev = mnlireader.get_dev_examples(MNLI_DIR)
    # mnli_test = mnlireader.get_test_examples(MNLI_DIR)
    # print("****Mnli*****\n")
    # print("train: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(mnli_train)))
    # print("dev: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(mnli_dev)))
    # print("test: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(mnli_test)))
    #
    # helpreader = HelpReader()
    # help = helpreader.get_test_examples(HELP_DIR)
    # print("****Help*****\n")
    # print("train: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(help)))
    #
    # medreader = MedReader()
    # med = medreader.get_test_examples(MED_DIR)
    # print("****Med*****\n")
    # print("train: mainp:{}, maxp:{}, avgp:{}, mainh:{}, maxh:{}, avgh:{}\n".format(*count_length(med)))
    # print(1)

    reader = EntBankReader(task='task_2')
    data = reader.get_test_examples(ENTBANK_DIR)

    print(1)