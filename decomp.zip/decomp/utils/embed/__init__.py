# from .general import Embed

from abc import ABCMeta, abstractmethod
import numpy as np

class Embed(metaclass=ABCMeta):
    @abstractmethod
    def __init__(self):
        self.model_name
        self.model
        self.dim
        self.max_length
        self.do_lower_case
        self.unk
        self.padding

    @abstractmethod
    def get_output_embeddings(self, examples, batch_size=None, split_sentence=True) -> (np.array, np.array):
        """ Get Embedding """
        pass

from .bert import BERT_MODEL_LIST, BertEmbed
from .glove import GloveEmbed
from .sentence import avg_embed
from .vocab import *
