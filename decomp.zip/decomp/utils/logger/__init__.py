import logging
import os
from logging.handlers import RotatingFileHandler

# logger = logging.getLogger(__name__)

def print_and_log(logger, logfile_path=None, formatter="default", mode='w'):
    if logfile_path is not None:
        dir_name = os.path.dirname(logfile_path)
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

    if formatter == "default":
        formatter = set_formatters()

    if logfile_path is not None:
    # FileHandler: print in the log file
        fh = RotatingFileHandler(logfile_path, mode=mode)
        fh.setFormatter(formatter)
        # add Handler
        logger.addHandler(fh)

    # StreamHandler: print on the console
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    # add Handler
    logger.addHandler(ch)

    return logger

def set_formatters():
    return logging.Formatter(fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                             datefmt="%Y-%m-%d %H:%M:%S")


if __name__ == '__main__':
    from config import LOG_DIR

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger = print_and_log(logger, os.path.join(LOG_DIR, 'test.log'))
    logger.info("test")
    logger.warning("warn")