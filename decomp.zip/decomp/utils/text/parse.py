from stanza.server import CoreNLPClient
import re


def parseTree2str(tree):
    tree_str = ''
    stack = [tree]
    token_num = 0
    assess = 0
    while len(stack) > 0:
        node = stack.pop()
        if node == ')':
            tree_str += ')'
            assess -= 1
            continue
        if len(node.child) == 0:
            # leaf node
            tree_str += node.value + ' ' + str(token_num)
            token_num += 1
        else:
            tree_str += '(' + node.value + ' '
            assess += 1
        if len(node.child) > 0:
            # reverse add to stack
            stack.append(')')
            stack.extend(node.child[::-1])

    assert assess == 0
    return tree_str

def find_parenthes(text):
    stack = []
    for i, c in enumerate(text):
        if c == '(':
            stack.append(i)
        elif c == ')' and stack:
            start = stack.pop()
            yield text[start + 1: i]



def find_node_idx_and_parent(text, np):
    for s in find_parenthes(text):
        idxes = [substr.start() for substr in re.finditer("\("+np, s)]
        # idx = s.find("("+np)
        for idx in idxes:
            if idx != -1:
                stack = []
                for prev in s[0:idx]:
                    if prev == "(":
                        stack.append([prev])
                    elif prev == ")":
                        stack.pop()
                if len(stack) == 0:
                    left_num = s[:idx+1].count('(') - s[:idx+1].count(')')
                    pp_text = ''
                    for right_idx, i in enumerate(s[idx+1:]):
                        if i == '(':
                            left_num += 1
                        elif i == ')':
                            left_num -= 1
                            if left_num == 0:
                                pp_text = s[idx+1: idx+1+right_idx]
                                break
                    num = re.findall(r'\d+', pp_text)
                    num = [int(i) for i in num]
                    yield (min(num), max(num), s[:s.find(' ')])


def find_node_and_parent(text, np):
    for s in find_parenthes(text):
        idx = s.find("("+np)
        if idx != -1:
            stack = []
            for prev in s[0:idx]:
                if prev == "(":
                    stack.append([prev])
                elif prev == ")":
                    stack.pop()
            if len(stack) == 0:
                c = re.findall(r" [a-z0-9']+[^ \)]", s[idx+1:])
                yield ((''.join(c)).strip(), s[:s.find(' ')])


def token2sentence(tokens):
    return ' '.join(tokens).replace(" n't", "n't").replace(" ,", ",").replace(" - ", "-").replace(" '", "'")


def get_n(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        if pos_list[idx][0:2] == 'NN' and pos_list[idx+1][0:2] != 'NN':
            idx_list.append(idx)
    if pos_list[-1][0:2] == 'NN':
        idx_list.append(len(pos_list)-1)
    return idx_list


def get_v(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        if pos_list[idx][0:2] == 'VB' and pos_list[idx+1][0:2] != 'VB':
            idx_list.append(idx)
    if pos_list[-1][0:2] == 'VB':
        idx_list.append(len(pos_list)-1)
    return idx_list

def get_adj(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        # adj
        if pos_list[idx][0:2] == 'JJ':
            idx_list.append(idx)
        # n as adj
        if pos_list[idx][0:2] == 'NN' and pos_list[idx+1][0:2] == 'NN':
            idx_list.append(idx)
    # if pos_list[-1][0:2] == 'JJ':
    #     idx_list.append(len(pos_list)-1)
    return idx_list

def get_adv(pos_list):
    idx_list = []
    for idx in range(len(pos_list)):
        # adv
        if pos_list[idx][0:2] == 'RB':
            idx_list.append(idx)
    return idx_list


def get_not_sentence(tokens, lemma, pos_list):
    v_idx = [i for i in range(len(tokens)) if pos_list[i][0:2] == 'VB']
    not_idx = []  # add not in front of the idx in this list
    do_idx = [] # add do/does in front of not
    s_idx = [] # ori idx
    new_lemma = []
    for i in v_idx:
        if (i+1) not in v_idx:
            not_idx.append(i)
            if pos_list[i-1][0:2] == "MD":
                not_idx.append(i)
            elif (i-1) not in v_idx:
                do_idx.append(i)

    s = ''
    for i in range(len(tokens)):
        if i in do_idx:
            if pos_list[i][0:3] == 'VBD':
                s += ' did'
                s_idx.append(-1)
                new_lemma.append('do')
            elif pos_list[i][0:3] in ['VBP', 'VBZ']:
                s += ' does'
                s_idx.append(-1)
                new_lemma.append('do')
            elif pos_list[i][0:3] not in ['VBG', 'VBN']:
                s += ' do'
                s_idx.append(-1)
                new_lemma.append('do')
        if i in not_idx:
            s = s + ' not '+ lemma[i]
            s_idx.append(-1)
            s_idx.append(i)
            new_lemma.append('not')
            new_lemma.append(lemma[i])
        else:
            s = s + ' ' + tokens[i]
            s_idx.append(i)
            new_lemma.append(lemma[i])

    return s.strip(), s_idx, new_lemma

def simple_tokenize(s):
    t = s.split()
    tokens = []
    for i in t:
        if i[-3:] == "n't":
            tokens.append(i[:-3])
            tokens.append(i[-3:])
        elif "-" in i:
            tmp = i.split('-')
            tokens.append(tmp[0])
            for j in range(len(tmp)-1):
                tokens.append('-')
                tokens.append(tmp[j+1])
        else:
            tokens.append(i)

    return tokens

def get_subsentence(s, lemma):
    # let s after another sentence, lemma is the lemma of the first token
    if lemma in ['NNP', 'NNPS']:
        return s
    else:
        return s[0].lower() + s[1:]



if __name__ == "__main__":
    ori = "A man in a white striped shirt and blue jeans using a water hose to spray water on the ground of concrete ruins.Fo".split()
    s = "(ROOT (NP (NP (DT A 0)(NN man 1))(PP (IN in 2)(NP (NP (DT a 3)(JJ white 4)(JJ striped 5)(NN shirt 6))(CC and 7)(S (NP (JJ blue 8)(NNS jeans 9))(VP (VBG using 10)(NP (DT a 11)(NN water 12)(NN hose 13))(PP (IN to 14)(NP (NN spray 15)(NN water 16)))(PP (IN on 17)(NP (NP (DT the 18)(NN ground 19))(PP (IN of 20)(NP (JJ concrete 21)(NN ruins.Fo 22)))))))))))"
    pp = list(find_node_idx_and_parent(s, 'PP '))
    print(pp)
    for i in pp:
        print(' '.join(ori[i[0]:i[1]+1]))

