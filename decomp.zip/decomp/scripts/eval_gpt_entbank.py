import os
import re
import dill as pickle
from collections import Counter
import itertools
from tqdm import tqdm
from datetime import datetime
from config.data_config import ENTBANK_DIR, BASE_DIR

def eval_leaf(label, predict):
    assert len(label) == len(predict)
    precision_strict = list()
    recall_strict = list()
    acc_strict = list()
    precision = list()
    recall = list()
    zero_acc = list()
    nonzero_p = list()
    nonzero_r = list()

    # precision  predict<label
    for idx in range(len(label)):
        # strict version
        if len(predict[idx]) == 0 and len(label[idx]) == 0:
            precision_strict.append(1)
        elif len(predict[idx]) == 0 and len(label[idx]) != 0:
            precision_strict.append(0)
        elif (all(x in label[idx] for x in predict[idx])):
            precision_strict.append(1)
        else:
            precision_strict.append(0)

        # normal version
        if len(predict[idx]) == 0 and len(label[idx]) == 0:
            precision.append(1)
        elif len(predict[idx]) == 0 and len(label[idx]) != 0:
            precision.append(0)
        else:
            for i in predict[idx]:
                if i in label[idx]:
                    precision.append(1)
                else:
                    precision.append(0)
        # nonzero
        if len(label[idx]) != 0:
            for i in predict[idx]:
                if i in label[idx]:
                    nonzero_p.append(1)
                else:
                    nonzero_p.append(0)

    # recall  predict>label
    for idx in range(len(label)):
        # strict version
        if len(label[idx]) == 0 and len(predict[idx]) == 0 :
            recall_strict.append(1)
        elif len(label[idx]) == 0 and len(predict[idx]) != 0:
            recall_strict.append(0)
        elif (all(x in predict[idx] for x in label[idx])):
            recall_strict.append(1)
        else:
            recall_strict.append(0)


        # normal version
        if len(label[idx]) == 0 and len(predict[idx]) == 0 :
            recall.append(1)
        elif len(label[idx]) == 0 and len(predict[idx]) != 0:
            recall.append(0)
        else:
            for i in label[idx]:
                if i in predict[idx]:
                    recall.append(1)
                else:
                    recall.append(0)
        # nonzero
        if len(label[idx]) != 0:
            for i in label[idx]:
                if i in predict[idx]:
                    nonzero_r.append(1)
                else:
                    nonzero_r.append(0)

    # acc
    for idx in range(len(label)):
        if set(predict[idx]) == set(label[idx]):
            acc_strict.append(1)
        else:
            acc_strict.append(0)

        if len(label[idx]) == 0:
            if len(predict[idx]) == 0:
                zero_acc.append(1)
            else:
                zero_acc.append(0)

    print("Acc_sctrict: ")
    print(len([i for i in acc_strict if i == 1]))
    print(Counter([len(label[idx]) for idx,f in enumerate(acc_strict) if f == 1]))
    precision_strict_score = sum(precision_strict)/len(precision_strict)
    recall_strict_score = sum(recall_strict)/len(recall_strict)
    acc_strict_score = sum(acc_strict)/len(acc_strict)
    precision_score = sum(precision)/len(precision)
    recall_score = sum(recall)/len(recall)
    nonzero_precision_score = sum(nonzero_p)/len(nonzero_p)
    nonzero_recall_score = sum(nonzero_r)/len(nonzero_r)
    zero_acc_score = sum(zero_acc)/len(zero_acc)
    return {
        # "precision_strict": format(precision_strict_score, '.4f'),
        # "recall_strict": format(recall_strict_score, '.4f'),
        "acc_strict": format(acc_strict_score, '.4f'),
        # "f1_strict": format(2*(recall_strict_score * precision_strict_score) / (recall_strict_score + precision_strict_score), '.4f'),
        "precision": format(precision_score, '.4f'),
        "recall": format(recall_score, '.4f'),
        "nonzero_p": format(nonzero_precision_score, '.4f'),
        "nonzero_r": format(nonzero_recall_score, '.4f'),
        "zero_acc": format(zero_acc_score, '.4f')

    }


def find_sc(predict):
    sc = list()
    for idx, pre in enumerate(predict):
        # if idx == 39:
        #     print(1)
        line = ['n' if len(i) == 0 else i for i in pre]
        flat_line = list(itertools.chain(*line))
        counter = Counter(flat_line)
        freq = counter.most_common()[0][1]

        this_sc = [k for k, f in counter.items() if f == freq]
        if len(this_sc) > 1 and 'n' in this_sc:
            this_sc.remove('n')
        this_sc = [[] if i == 'n' else i for i in this_sc]
        if this_sc == [[]]:
            this_sc = []
        sc.append(this_sc)
    return sc

def find_union(predict):
    sc = list()
    for pre in predict:
        line = ['n' if len(i) == 0 else i for i in pre]
        flat_line = list(itertools.chain(*line))
        if 'n' in flat_line:
            flat_line.remove('n')
        sc.append(flat_line)
    return sc

def rm_gold_sent(gold_sent, predict):
    new_predict = list()
    for idx in range(len(gold_sent)):
        this_predict = [list(set(i)-set(gold_sent[idx])) for i in predict[idx]]
        new_predict.append(this_predict)
    return new_predict


if __name__ == "__main__":
    task = 'task_2'
    version = 'sc7_v4'
    split = 'dev'
    sc_num = 7
    second = True

    output_dir = os.path.join(BASE_DIR, 'output', 'decomp_gpt')
    file_name = 'out_dev_gpt-4_sc7_v4_06-01-01-01.pkl'
    # out_dev_turbo_sc3_v1_05-19-09-18.pkl
    # out_dev_turbo_sc3_v2_05-26-05-56.pkl
    # out_dev_turbo_sc7_v2_05-26-10-50
    # out_dev_turbo_sc7_v3_05-26-11-14.pkl
    # out_dev_gpt-3.5-turbo_sc50_v4_06-01-07-41.pkl

    # out_dev_gpt-4_sc7_v3_05-29-16-01.pkl
    # out_dev_gpt-4_sc7_v4_06-01-01-01.pkl

    with open(os.path.join(output_dir, file_name),'rb') as f:
        response_list = pickle.load(f)

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, split + '.pkl'),'rb') as f:
        gt_data = pickle.load(f)

    first_r = list()
    sec_r = list()
    for response in response_list:
        first_r.append([r['message']['content'] for r in response[0]['choices']])
        if second:
            sec_r.append([response[i]['choices'][0]['message']['content'] for i in range(1, sc_num+1)])

    print(1)
    first_ans = list()
    sec_ans = list()
    gt_missing = list()
    gt_sent = list()
    for res in gt_data:
        this_a = list()
        for r in res['gold_sent_new']:
            this_a.extend(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        gt_sent.append(this_a)

    for res in first_r:
        this_a = list()
        for r in res:
            this_a.append(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        first_ans.append(this_a)
    first_ans = rm_gold_sent(gold_sent=gt_sent, predict=first_ans)

    if second:
        for res in sec_r:
            this_a = list()
            for r in res:
                this_a.append(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
            sec_ans.append(this_a)
        sec_ans = rm_gold_sent(gold_sent=gt_sent, predict=sec_ans)

    for res in gt_data:
        this_a = list()
        for r in res['missing']:
            this_a.extend(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        gt_missing.append(this_a)


    # # eval 1, first ans of the first_round_ans
    # res1 = [i[0] for i in first_ans]
    # eval1 = eval_leaf(label=gt_missing, predict=res1)
    # len1 = [len(i) for i in res1]
    #
    # # eval 2, first ans of the sec_round_ans  (whether the second round is useful)
    # res2 = [i[0] for i in sec_ans]
    # eval2 = eval_leaf(label=gt_missing, predict=res2)
    # len2 = [len(i) for i in res2]

    # eval 3, first_round_ans -> self-consistency  (whether the second round is useful, compared with 4)
    res3 = find_sc(first_ans)
    eval3 = eval_leaf(label=gt_missing, predict=res3)
    len3 = [len(i) for i in res3]

    if second:
        # eval 4, second_round_ans -> self-consistency (whether sc is useful, compared with 2)
        res4 = find_sc(sec_ans)
        eval4 = eval_leaf(label=gt_missing, predict=res4)
        len4 = [len(i) for i in res4]

    # eval 5, eval_2 test recall (whether sc is useful, compared with 1,3)
    res5 = find_union(first_ans)
    eval5 = eval_leaf(label=gt_missing, predict=res5)
    len5 = [len(i) for i in res5]

    if second:
        # eval 6, eval_4 test recall (whether sc is useful, compared with 2,4)
        res6 = find_union(sec_ans)
        eval6 = eval_leaf(label=gt_missing, predict=res6)
        len6 = [len(i) for i in res6]



    # print("res1:")
    # print(eval1)
    # print(Counter(len1))
    # print('\n')
    # print("res2:")
    # print(eval2)
    # print(Counter(len2))
    # print('\n')
    print("res3:")
    print(eval3)
    print(Counter(len3))
    print('\n')
    if second:
        print("res4:")
        print(eval4)
        print(Counter(len4))
        print('\n')
    print("res5:")
    print(eval5)
    print(Counter(len5))
    print('\n')
    if second:
        print("res6:")
        print(eval6)
        print(Counter(len6))
    print('done')