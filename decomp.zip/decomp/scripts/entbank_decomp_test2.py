import os
import dill as pickle
import openai
from tqdm import tqdm
from datetime import datetime
from config.data_config import ENTBANK_DIR, BASE_DIR
import backoff
import time

@backoff.on_exception(backoff.expo, openai.error.RateLimitError)
def completions_with_backoff(**kwargs):
    return openai.ChatCompletion.create(**kwargs)

def concat_sent(sent_label_list):
    if len(sent_label_list) <= 1:
        return ', '.join(sent_label_list)
    elif len(sent_label_list) == 2:
        return sent_label_list[0] + ' and ' + sent_label_list[-1]
    else:
        return ', '.join(sent_label_list[0:-1]) + ' and ' + sent_label_list[-1]



if __name__ == "__main__":
    task = 'task_2'
    version = 'sc50_v4'
    split = 'dev'
    sc_num = 50

    # Mine for turbo
    openai.organization = ""
    openai.api_key = ""  # Mine for turbo

    

    gpt_model = "gpt-3.5-turbo"
    # gpt_model = "gpt-4"

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, split + '.pkl'),'rb') as f:
        data = pickle.load(f)

    output_dir = os.path.join(BASE_DIR, 'output', 'decomp_gpt')
    date = datetime.now().strftime("%m-%d-%H-%M")
    input_file_name = "in_{split}_{v}_{date}.txt".format(split=split, v=version, date=date)
    # output_file_name = "out_{split}_{model}_{v}_{date}.txt".format(split=split, model="turbo", v=version, date=date)
    output_pickle_name = "out_{split}_{model}_{v}_{date}.pkl".format(split=split, model=gpt_model, v=version, date=date)

    # # v3
    # prompt_system = "You are trying to deduce the hypothesis using some of the following context sentences."
    #
    # prompt_template = "Hypothesis: {h}\n" \
    #                   "Context:\n{context}\n" \
    #                   "If '{gold_sent_new}' are known to be relevant, which sentence(s) is/are also needed to deduce the above hypothesis? " \
    #                   "Please provide the proof chain and reply the missing sentences, if any, with the sentence serial number, e.g. sent1. " \
    #                   "If the hypothesis cannot be deduced directly from the sentences, then indicate your intermediate reasoning steps and " \
    #                   "the context sentences that support them when writing the proof chain. " \
    #                   "When you reason, please do not assume any knowledge except those listed in the context."
    # # "If no sentences are needed other than '{gold_sent_new}', please reply 0. " \
    # prompt_conlude = "Upon the previous discussion, the missing sentence(s) is/are: (Reply the sentence serial number, e.g. sent1. " \
    #                  "If no additional sentences other than '{gold_sent_new}' are needed reply 0)"

    # v4
    prompt_system = "Below, you are given a hypothesis and a set of candidate premises."
    prompt_template = "Hypothesis: {h}\n" \
                      "Candidate/potential premises:\n{context}\n" \
                      "If {gold_sent_new} are known to be the necessary premises required to deduce the above hypothesis, " \
                      "which premise(s) among the above candidates is/are still missing in order to deduce the above hypothesis? " \
                      "Please provide the missing premise(s) using the premise IDs, e.g. sent1. Please provide your proof steps, " \
                      "including intermediate conclusions. If you cannot deduce the hypothesis, please still provide me " \
                      "with intermediate reasoning steps and intermediate conclusions, and tell me that \"The hypothesis " \
                      "cannot be proved\". When you reason, please do not assume you know any other knowledge except " \
                      "those listed above as the candidate/potential premises."
    prompt_conlude = "Upon the previous discussion, the missing sentence(s) is/are: (Reply the sentence serial number, e.g. sent1. " \
                     "If no additional sentences other than '{gold_sent_new}' are needed reply 0)"

    prompt_list = list()
    with open(os.path.join(output_dir, input_file_name), "w") as f:
        for idx, ex in enumerate(data):
            context = ''.join(["{}: {}\n".format(k,v) for k,v in ex['contexts'].items()])
            gold_sent_new_text = concat_sent(ex['gold_sent_new'])
            p1 = prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=gold_sent_new_text)
            p2 = prompt_conlude.format(gold_sent_new=gold_sent_new_text)
            prompt_list.append([p1, p2])

            f.write("{}:\n".format(idx))
            f.write(p1)
            f.write("\n")
            f.write(p2)
            f.write("\n\n\n")



    # openai.organization = "org-udLQKjlz4HfJHiSR2xuFSJTA"
    # openai.api_key = "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"

    response = list()
    for prompt in tqdm(prompt_list):
        while(True):
            try:
                r0 = completions_with_backoff(
                # r0 = openai.ChatCompletion.create(
                    model=gpt_model,
                    messages=[{"role": "system", "content": prompt_system},
                              {"role": "user", "content": prompt[0]}],
                    n=sc_num
                )
                break
            except Exception as e:
                print(f"Error was: {e}")
                print(f"Waiting 10 minutes and try again")
                time.sleep(600)
        this_response = [r0]
        # for reply_n in range(sc_num):
        #     while(True):
        #         try:
        #             r = completions_with_backoff(
        #             # r = openai.ChatCompletion.create(
        #                 model=gpt_model,
        #                 messages=[{"role": "system", "content": prompt_system},
        #                           {"role": "user", "content": prompt[0]},
        #                           {"role": "assistant", "content": r0.choices[reply_n]['message']['content']},
        #                           {"role": "user", "content": prompt[1]}]
        #             )
        #             break
        #         except Exception as e:
        #             print(f"Error was: {e}")
        #             print(f"Waiting 10 minutes and try again")
        #             time.sleep(600)
        #     this_response.append(r)
        #

        response.append(this_response)

    with open(os.path.join(output_dir, output_pickle_name), 'wb') as file:
        pickle.dump(response, file)

