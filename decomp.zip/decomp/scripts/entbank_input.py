import os
import dill as pickle
import random
import numpy as np
from config.data_config import ENTBANK_DIR
from utils.data_utils import EntBankReader


if __name__ == "__main__":
    task = 'task_2'
    output_dir = os.path.join(ENTBANK_DIR, 'cases')

    file_name = "test.txt"

    entbank_reader = EntBankReader(task)

    # train_data = entbank_reader.get_train_examples(ENTBANK_DIR)
    # dev_data = entbank_reader.get_dev_examples(ENTBANK_DIR)
    test_data = entbank_reader.get_test_examples(ENTBANK_DIR)
    # all_data = train_data + dev_data + test_data

    # # for data in [train_data, dev_data, test_data, all_data]:
    # for data in test_data:
    #     contexts = [len(i['contexts']) for i in data]
    #     gold_sent = [len(i['gold_sent']) for i in data]
    #     depth_of_proof = [i['depth_of_proof'] for i in data]
    #     length_of_proof = [i['length_of_proof']for i in data]
    #     # print("context: min:{}, max:{}, avg:{}, med:{}".format(min(contexts), max(contexts), sum(contexts)/len(contexts), np.quantile(contexts, 0.5)))
    #     # print("gold_sent: min:{}, max:{}, avg:{}, quantile1:{}, med:{}, quantile3:{}".format(min(gold_sent), max(gold_sent), sum(gold_sent)/len(gold_sent), np.quantile(gold_sent, 0.25), np.quantile(gold_sent, 0.5), np.quantile(gold_sent, 0.75)))
    #     # print("depth_of_proof: min:{}, max:{}, avg:{}, med:{}".format(min(depth_of_proof), max(depth_of_proof), sum(depth_of_proof)/len(depth_of_proof), np.quantile(depth_of_proof, 0.5)))
    #     # print("length_of_proof: min:{}, max:{}, avg:{}, med:{}".format(min(length_of_proof), max(length_of_proof), sum(length_of_proof)/len(length_of_proof), np.quantile(length_of_proof, 0.5)))
    #     print("==========")


    with open(os.path.join(output_dir, file_name), "w") as f:
        for idx, ex in enumerate(test_data):

            context = ''.join(["{}: {}\n".format(k,v) for k,v in ex['contexts'].items()])

            f.write("example{}:\nid: {}\nproof_depth: {}, proof_length: {}\n\n".format(idx, ex['id'], ex['depth_of_proof'], ex['length_of_proof']))
            f.write("Question: {}\n".format(ex['question'].strip()))
            f.write("Hypothesis: {}\n".format(ex['hypothesis'].strip()))
            f.write("Candidate/potential premises:\n{}\n".format(context))
            f.write("Ground truth proof:\n{}\n".format(';\n'.join([i.strip() for i in ex['proof'].split(';')])))
            f.write("===================")
            f.write('\n\n\n')


    print(1)