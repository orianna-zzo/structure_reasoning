import os
import dill as pickle
import random
import numpy as np
from config.data_config import ENTBANK_DIR
from utils.data_utils import EntBankReader


if __name__ == "__main__":
    task = 'task_2'

    entbank_reader = EntBankReader(task)

    train_data = entbank_reader.get_train_examples(ENTBANK_DIR)
    dev_data = entbank_reader.get_dev_examples(ENTBANK_DIR)
    test_data = entbank_reader.get_test_examples(ENTBANK_DIR)
    all_data = train_data + dev_data + test_data

    for data in [train_data, dev_data, test_data, all_data]:
        contexts = [len(i['contexts']) for i in data]
        gold_sent = [len(i['gold_sent']) for i in data]
        depth_of_proof = [i['depth_of_proof'] for i in data]
        length_of_proof = [i['length_of_proof']for i in data]
        print("context: min:{}, max:{}, avg:{}, med:{}".format(min(contexts), max(contexts), sum(contexts)/len(contexts), np.quantile(contexts, 0.5)))
        print("gold_sent: min:{}, max:{}, avg:{}, quantile1:{}, med:{}, quantile3:{}".format(min(gold_sent), max(gold_sent), sum(gold_sent)/len(gold_sent), np.quantile(gold_sent, 0.25), np.quantile(gold_sent, 0.5), np.quantile(gold_sent, 0.75)))
        print("depth_of_proof: min:{}, max:{}, avg:{}, med:{}".format(min(depth_of_proof), max(depth_of_proof), sum(depth_of_proof)/len(depth_of_proof), np.quantile(depth_of_proof, 0.5)))
        print("length_of_proof: min:{}, max:{}, avg:{}, med:{}".format(min(length_of_proof), max(length_of_proof), sum(length_of_proof)/len(length_of_proof), np.quantile(length_of_proof, 0.5)))
        print("==========")

    for i in train_data:
        if len(i['gold_sent']) < 3:
            i['missing'] = []
            i['gold_sent_new'] = i['gold_sent']
        elif len(i['gold_sent']) > 5:
            i['missing'] = random.sample(i['gold_sent'], k=2)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))
        else:
            i['missing'] = random.sample(i['gold_sent'], k=1)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, 'train.pkl'), 'wb') as file:
        pickle.dump(train_data, file)

    for i in dev_data:
        if len(i['gold_sent']) < 3:
            i['missing'] = []
            i['gold_sent_new'] = i['gold_sent']
        elif len(i['gold_sent']) > 5:
            i['missing'] = random.sample(i['gold_sent'], k=2)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))
        else:
            i['missing'] = random.sample(i['gold_sent'], k=1)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, 'dev.pkl'), 'wb') as file:
        pickle.dump(dev_data, file)

    for i in test_data:
        if len(i['gold_sent']) < 3:
            i['missing'] = []
            i['gold_sent_new'] = i['gold_sent']
        elif len(i['gold_sent']) > 5:
            i['missing'] = random.sample(i['gold_sent'], k=2)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))
        else:
            i['missing'] = random.sample(i['gold_sent'], k=1)
            i['gold_sent_new'] = list(set(i['gold_sent']) - set(i['missing']))

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, 'test.pkl'), 'wb') as file:
        pickle.dump(test_data, file)

    print("After Data Generation...")
    all_data = train_data + dev_data + test_data
    for data in [train_data, dev_data, test_data, all_data]:
        missing = [len(i['missing']) for i in data]
        gold_sent_new = [len(i['gold_sent_new']) for i in data]
        print("missing: 0:{}, 1:{}, 2:{}".format(missing.count(0), missing.count(1), missing.count(2)))
        print("gold_sent_new: min:{}, max:{}, avg:{}, quantile1:{}, med:{}, quantile3:{}".format(min(gold_sent_new), max(gold_sent_new), sum(gold_sent_new)/len(gold_sent_new), np.quantile(gold_sent_new, 0.25), np.quantile(gold_sent_new, 0.5), np.quantile(gold_sent_new, 0.75)))
        print("==========")

    #
    #
    # gold_by_id = {g['id']: g for g in gold_data}
    #
    # train_context_dict = dict()
    # train_answers_dict = dict()
    # for g in gold_data:
    #     # print(f"{g['meta']['triples']}")
    #     context_dict = dict(g['meta']['triples'])
    #     for context in context_dict.values():
    #         train_context_dict[context] = 1
    #     train_answers_dict[g['answer']] = 1

    print(1)