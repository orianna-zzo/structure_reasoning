import os
import re
import dill as pickle
from collections import Counter
import itertools
from tqdm import tqdm
from datetime import datetime
from config.data_config import ENTBANK_DIR, BASE_DIR

def eval_leaf(label, predict):
    assert len(label) == len(predict)
    precision_strict = list()
    recall_strict = list()
    acc_strict = list()
    precision = list()
    recall = list()
    zero_acc = list()
    nonzero_p = list()
    nonzero_r = list()

    # precision  predict<label
    for idx in range(len(label)):
        # strict version
        if len(predict[idx]) == 0 and len(label[idx]) == 0:
            precision_strict.append(1)
        elif len(predict[idx]) == 0 and len(label[idx]) != 0:
            precision_strict.append(0)
        elif (all(x in label[idx] for x in predict[idx])):
            precision_strict.append(1)
        else:
            precision_strict.append(0)

        # normal version
        if len(predict[idx]) == 0 and len(label[idx]) == 0:
            precision.append(1)
        elif len(predict[idx]) == 0 and len(label[idx]) != 0:
            precision.append(0)
        else:
            for i in predict[idx]:
                if i in label[idx]:
                    precision.append(1)
                else:
                    precision.append(0)
        # nonzero
        if len(label[idx]) != 0:
            for i in predict[idx]:
                if i in label[idx]:
                    nonzero_p.append(1)
                else:
                    nonzero_p.append(0)

    # recall  predict>label
    for idx in range(len(label)):
        # strict version
        if len(label[idx]) == 0 and len(predict[idx]) == 0 :
            recall_strict.append(1)
        elif len(label[idx]) == 0 and len(predict[idx]) != 0:
            recall_strict.append(0)
        elif (all(x in predict[idx] for x in label[idx])):
            recall_strict.append(1)
        else:
            recall_strict.append(0)


        # normal version
        if len(label[idx]) == 0 and len(predict[idx]) == 0 :
            recall.append(1)
        elif len(label[idx]) == 0 and len(predict[idx]) != 0:
            recall.append(0)
        else:
            for i in label[idx]:
                if i in predict[idx]:
                    recall.append(1)
                else:
                    recall.append(0)
        # nonzero
        if len(label[idx]) != 0:
            for i in label[idx]:
                if i in predict[idx]:
                    nonzero_r.append(1)
                else:
                    nonzero_r.append(0)

    # acc
    for idx in range(len(label)):
        if set(predict[idx]) == set(label[idx]):
            acc_strict.append(1)
        else:
            acc_strict.append(0)

        if len(label[idx]) == 0:
            if len(predict[idx]) == 0:
                zero_acc.append(1)
            else:
                zero_acc.append(0)

    print("Acc_sctrict: ")
    print(len([i for i in acc_strict if i == 1]))
    print(Counter([len(label[idx]) for idx,f in enumerate(acc_strict) if f == 1]))
    precision_strict_score = sum(precision_strict)/len(precision_strict)
    recall_strict_score = sum(recall_strict)/len(recall_strict)
    acc_strict_score = sum(acc_strict)/len(acc_strict)
    precision_score = sum(precision)/len(precision)
    recall_score = sum(recall)/len(recall)
    nonzero_precision_score = sum(nonzero_p)/len(nonzero_p)
    nonzero_recall_score = sum(nonzero_r)/len(nonzero_r)
    if len(zero_acc)!=0:
        zero_acc_score = sum(zero_acc)/len(zero_acc)
    else:
        zero_acc_score = 0
    return {
        # "precision_strict": format(precision_strict_score, '.4f'),
        # "recall_strict": format(recall_strict_score, '.4f'),
        "acc_strict": format(acc_strict_score, '.4f'),
        # "f1_strict": format(2*(recall_strict_score * precision_strict_score) / (recall_strict_score + precision_strict_score), '.4f'),
        "precision": format(precision_score, '.4f'),
        "recall": format(recall_score, '.4f'),
        "nonzero_p": format(nonzero_precision_score, '.4f'),
        "nonzero_r": format(nonzero_recall_score, '.4f'),
        "zero_acc": format(zero_acc_score, '.4f')

    }

def concat_sent(sent_label_list):
    if len(sent_label_list) <= 1:
        return ', '.join(sent_label_list)
    elif len(sent_label_list) == 2:
        return sent_label_list[0] + ' and ' + sent_label_list[-1]
    else:
        return ', '.join(sent_label_list[0:-1]) + ' and ' + sent_label_list[-1]

def find_sc(predict):
    sc = list()
    for idx, pre in enumerate(predict):
        # if idx == 39:
        #     print(1)
        line = ['n' if len(i) == 0 else i for i in pre]
        flat_line = list(itertools.chain(*line))
        counter = Counter(flat_line)
        freq = counter.most_common()[0][1]

        this_sc = [k for k, f in counter.items() if f == freq]
        if len(this_sc) > 1 and 'n' in this_sc:
            this_sc.remove('n')
        this_sc = [[] if i == 'n' else i for i in this_sc]
        if this_sc == [[]]:
            this_sc = []
        sc.append(this_sc)
    return sc

def find_union(predict):
    sc = list()
    for pre in predict:
        line = ['n' if len(i) == 0 else i for i in pre]
        flat_line = list(itertools.chain(*line))
        if 'n' in flat_line:
            flat_line.remove('n')
        sc.append(flat_line)
    return sc

def rm_gold_sent(gold_sent, predict):
    new_predict = list()
    for idx in range(len(gold_sent)):
        this_predict = [list(set(i)-set(gold_sent[idx])) for i in predict[idx]]
        new_predict.append(this_predict)
    return new_predict


if __name__ == "__main__":
    task = 'task_2'
    version = 'sc7_v4'
    split = 'dev'
    sc_num = 7
    second = True

    output_dir = os.path.join(BASE_DIR, 'output', 'decomp_gpt')
    file_name = 'out_dev_gpt-4_sc7_v4_06-01-01-01.pkl'
    # out_dev_turbo_sc3_v1_05-19-09-18.pkl
    # out_dev_turbo_sc3_v2_05-26-05-56.pkl
    # out_dev_turbo_sc7_v2_05-26-10-50
    # out_dev_turbo_sc7_v3_05-26-11-14.pkl
    # out_dev_gpt-3.5-turbo_sc50_v4_06-01-07-41.pkl

    # out_dev_gpt-4_sc7_v3_05-29-16-01.pkl
    # out_dev_gpt-4_sc7_v4_06-01-01-01.pkl

    error_file_name = "error_dev_gpt-4_sc7_v4_06-01-01-01_test_structure.txt"

    with open(os.path.join(output_dir, file_name),'rb') as f:
        response_list = pickle.load(f)

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, split + '.pkl'),'rb') as f:
        gt_data = pickle.load(f)

    first_r = list()
    for response in response_list:
        first_r.append([r['message']['content'] for r in response[0]['choices']])


    print(1)
    first_ans = list()
    gt_missing = list()
    gt_sent = list()
    for res in gt_data:
        this_a = list()
        for r in res['gold_sent_new']:
            this_a.extend(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        gt_sent.append(this_a)

    for res in first_r:
        this_a = list()
        for r in res:
            this_a.append(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        first_ans.append(this_a)
    first_ans = rm_gold_sent(gold_sent=gt_sent, predict=first_ans)

    for res in gt_data:
        this_a = list()
        for r in res['missing']:
            this_a.extend(list(set(re.compile('[Ss]ent(\d+)').findall(r))))
        gt_missing.append(this_a)


    depth_list = [i['depth_of_proof'] for i in gt_data]
    # eval 3, first_round_ans -> self-consistency  (whether the second round is useful, compared with 4)
    res3 = find_sc(first_ans)
    eval3 = eval_leaf(label=gt_missing, predict=res3)
    len3 = [len(i) for i in res3]

    print("res3:")
    print(eval3)
    print(Counter(len3))
    print('\n')

    for i in range(7):
        print(i+1)
        this_res = [j for idx, j in enumerate(res3) if depth_list[idx]==i+1]
        this_gt_missing = [j for idx, j in enumerate(gt_missing) if depth_list[idx]==i+1]
        print("total num:")
        print(len(this_res))
        print("distribution:")
        print(Counter([len(i) for i in this_gt_missing]))
        this_eval = eval_leaf(label=this_gt_missing, predict=this_res)
        # this_len = [len(i) for i in this_res]
        print(this_eval)
        # print(Counter(this_len))
        print('\n')


    # acc
    acc_strict = list()
    for idx in range(len(gt_missing)):
        if set(res3[idx]) == set(gt_missing[idx]):
            acc_strict.append(1)
        else:
            acc_strict.append(0)

    error_idx = [idx for idx, i in enumerate(acc_strict) if i == 0]

    # v4
    prompt_system = "Below, you are given a hypothesis and a set of candidate premises."
    prompt_template = "Hypothesis: {h}\n" \
                      "Candidate/potential premises:\n{context}\n" \
                      "If {gold_sent_new} are known to be the necessary premises required to deduce the above hypothesis, " \
                      "which premise(s) among the above candidates is/are still missing in order to deduce the above hypothesis? " \
                      "Please provide the missing premise(s) using the premise IDs, e.g. sent1. Please provide your proof steps, " \
                      "including intermediate conclusions. If you cannot deduce the hypothesis, please still provide me " \
                      "with intermediate reasoning steps and intermediate conclusions, and tell me that \"The hypothesis " \
                      "cannot be proved\". When you reason, please do not assume you know any other knowledge except " \
                      "those listed above as the candidate/potential premises."


    with open(os.path.join(output_dir, error_file_name), "w") as f:
        for idx, ex in enumerate(gt_data):
            if idx in error_idx:
                context = ''.join(["{}: {}\n".format(k,v) for k,v in ex['contexts'].items()])
                gold_sent_new = concat_sent(ex['gold_sent_new'])
                p1 = prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=gold_sent_new)


                f.write("example{}:\n".format(idx))
                f.write("System: " + prompt_system)
                f.write(p1)
                f.write("\n\n")
                f.write("Given sentences: {}\n".format(ex['gold_sent_new']))
                f.write("Missing sentence: {}\n".format(ex['missing']))
                f.write("Ground truth proof: {}\n".format(ex['proof']))
                f.write("Final Prediction: {}\n".format(res3[idx]))
                f.write("SC predictions: {}\n".format(first_ans[idx]))
                # f.write("Response:\n")
                for n, r in enumerate(first_r[idx]):
                    f.write("---\n")
                    f.write("Response{}: {}\n".format(n, r))
                f.write("=======\n\n\n")
                #



    print('done')