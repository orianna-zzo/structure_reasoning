import os
import dill as pickle
import openai
from tqdm import tqdm
from datetime import datetime
from config.data_config import ENTBANK_DIR, BASE_DIR
import backoff
import time
from collections import Counter
import itertools
import re

@backoff.on_exception(backoff.expo, openai.error.RateLimitError)
def completions_with_backoff(**kwargs):
    return openai.ChatCompletion.create(**kwargs)

def find_sc(predict):
    line = ['n' if len(i) == 0 else i for i in predict]
    flat_line = list(itertools.chain(*line))

    counter = Counter(flat_line)
    freq = counter.most_common()[0][1]
    this_sc = [k for k, f in counter.items() if f == freq]
    if freq == 1:
        this_sc = [k for k, f in counter.items() if f == freq]
        if 'n' in this_sc:
            this_sc.remove('n')
    else:
        this_sc = [k for k, f in counter.items() if f == freq]
    this_sc = [[] if i == 'n' else i for i in this_sc]
    if this_sc == [[]]:
        this_sc = []
    return this_sc

def search_demonstration(ex, database):
    pass


if __name__ == "__main__":
    task = 'task_2'
    version = 'sc7_search_v1'
    split = 'dev'
    sc_num = 7

    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, split + '.pkl'),'rb') as f:
        data = pickle.load(f)

    output_dir = os.path.join(BASE_DIR, 'output', 'decomp_gpt')
    date = datetime.now().strftime("%m-%d-%H-%M")
    input_file_name = "in_{split}_{v}_{date}.txt".format(split=split, v=version, date=date)
    # output_file_name = "out_{split}_{model}_{v}_{date}.txt".format(split=split, model="turbo", v=version, date=date)
    output_pickle_name = "out_{split}_{model}_{v}_{date}.pkl".format(split=split, model="turbo", v=version, date=date)

    prompt_system = "You are trying to deduce the hypothesis using some of the following context sentences."

    prompt_template = "Hypothesis: {h}\n" \
                      "Context:\n{context}\n" \
                      "If '{gold_sent_new}' are known to be relevant, which sentence is also needed to deduce the above hypothesis? " \
                      "Please provide the proof chain and reply the missing sentences, if any, with the sentence serial number, e.g. sent1. " \
                      "If the hypothesis cannot be deduced directly from the sentences, then indicate your intermediate reasoning steps and " \
                      "the context sentences that support them when writing the proof chain. " \
                      "When you reason, please do not assume any knowledge except those listed in the context."
    # "If no sentences are needed other than '{gold_sent_new}', please reply 0. " \
    prompt_conlude = "Upon the previous discussion, the missing sentence is: (Reply the sentence serial number, e.g. sent1. " \
                     "If no additional sentences other than '{gold_sent_new}' are needed reply 0)"

    openai.organization = ""
    openai.api_key = ""

    response = list()
    final_predict = list()
    with open(os.path.join(output_dir, input_file_name), "w") as f:
        for idx, ex in tqdm(enumerate(data)):
            demos = search_demonstration(ex, )
            ex['found'] = list()
            context = ''.join(["{}: {}\n".format(k,v) for k,v in ex['contexts'].items()])
            gold_sent_new_num = list()
            for i in ex['gold_sent_new']:
                gold_sent_new_num.extend(list(set(re.compile('[Ss]ent(\d+)').findall(i))))
            gold_sent_new_text = ', '.join(ex['gold_sent_new'])
            prompt1 = prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=gold_sent_new_text)
            prompt2 = prompt_conlude.format(gold_sent_new=gold_sent_new_text)

            f.write("{}:\n".format(idx))
            f.write(prompt1)
            f.write("\n")
            f.write(prompt2)
            f.write("\n\n\n")

            this_message = [{"role": "system", "content": prompt_system},
                            {"role": "user", "content": prompt1}]
            while(True):
                while(True):
                    try:
                        # first round answers
                        r0 = completions_with_backoff(
                            model="gpt-3.5-turbo",
                            messages=this_message,
                            n=sc_num
                        )
                        break
                    except Exception as e:
                        print(f"Error was: {e}")
                        print(f"Waiting 5 minutes and try again")
                        time.sleep(300)
                this_response = [r0]

                predict = list()
                for reply_n in range(sc_num):
                    this_message2 = this_message + [{"role": "assistant", "content": r0.choices[reply_n]['message']['content']},
                                                    {"role": "user", "content": prompt2}]
                    while(True):
                        try:
                            r = completions_with_backoff(
                                model="gpt-3.5-turbo",
                                messages=this_message2
                            )
                            break
                        except Exception as e:
                            print(f"Error was: {e}")
                            print(f"Waiting 5 minutes")
                            time.sleep(300)

                    this_response.append(r)
                    ans_content = r['choices'][0]['message']['content']
                    this_a = (list(set(re.compile('[Ss]ent(\d+)').findall(ans_content))))
                    predict.append(list(set(this_a)-set(gold_sent_new_num)))   # remove gold sent new
                predict_sc = find_sc(predict)
                if len(predict_sc) == 0:
                    final_predict.append(ex['found'])
                    break
                else:
                    ex['found'].extend(predict_sc)
                    gold_sent_new = ', '.join(ex['gold_sent_new']+ex['found'])
                    prompt1 = prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=gold_sent_new)
                    prompt2 = prompt_conlude.format(gold_sent_new=gold_sent_new)

                    f.write("{}:\n".format(idx))
                    f.write(prompt1)
                    f.write("\n")
                    f.write(prompt2)
                    f.write("\n\n\n")

                    this_message = [{"role": "system", "content": prompt_system},
                                    {"role": "user", "content": prompt1}]


        response.append(this_response)

    with open(os.path.join(output_dir, output_pickle_name), 'wb') as file:
        pickle.dump([response, final_predict], file)

