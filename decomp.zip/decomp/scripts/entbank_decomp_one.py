import os
import dill as pickle
import openai
from tqdm import tqdm
from datetime import datetime
from config.data_config import ENTBANK_DIR, BASE_DIR
import backoff
import time
import itertools
from collections import Counter
import re

@backoff.on_exception(backoff.expo, openai.error.RateLimitError)
def completions_with_backoff(**kwargs):
    return openai.ChatCompletion.create(**kwargs)

def concat_sent(sent_label_list):
    if len(sent_label_list) <= 1:
        return ', '.join(sent_label_list)
    elif len(sent_label_list) == 2:
        return sent_label_list[0] + ' and ' + sent_label_list[-1]
    else:
        return ', '.join(sent_label_list[0:-1]) + ' and ' + sent_label_list[-1]


def find_sc(predict):
    line = ['n' if len(i) == 0 else i for i in predict]
    flat_line = list(itertools.chain(*line))

    counter = Counter(flat_line)
    freq = counter.most_common()[0][1]
    this_sc = [k for k, f in counter.items() if f == freq]
    if freq == 1:
        this_sc = [k for k, f in counter.items() if f == freq]
        if 'n' in this_sc:
            this_sc.remove('n')
    else:
        this_sc = [k for k, f in counter.items() if f == freq]
    this_sc = [[] if i == 'n' else i for i in this_sc]
    if this_sc == [[]]:
        this_sc = []
    return this_sc


def find_sc_one(predict):
    line = ['n' if len(i) == 0 else i for i in predict]
    flat_line = list(itertools.chain(*line))

    counter = Counter(flat_line)
    freq_v = counter.most_common()[0][0]
    if freq_v == 'n':
        return ''
    else:
        return freq_v

def no_additional(text):
    i = re.compile('No additional premise is needed').findall(text)
    if len(i) > 0:
        return 1
    else:
        return 0


if __name__ == "__main__":
    task = 'task_2'
    version = 'sc7_one_v6'
    split = 'dev'
    sc_num = 7

    gpt_model = "gpt-3.5-turbo"
    # gpt_model = "gpt-4"

    # Mine for turbo
    openai.organization = ""
    openai.api_key = ""  # Mine for turbo

    


    with open(os.path.join(ENTBANK_DIR, 'decomp_data', task, split + '.pkl'),'rb') as f:
        data = pickle.load(f)

    output_dir = os.path.join(BASE_DIR, 'output', 'decomp_gpt')
    date = datetime.now().strftime("%m-%d-%H-%M")
    input_file_name = "in_{split}_{v}_{date}.txt".format(split=split, v=version, date=date)
    # output_file_name = "out_{split}_{model}_{v}_{date}.txt".format(split=split, model="turbo", v=version, date=date)
    output_pickle_name = "out_{split}_{model}_{v}_{date}.pkl".format(split=split, model=gpt_model, v=version, date=date)


    # # v5
    # prompt_system = "Below, you are given a hypothesis and a set of candidate premises."
    # prompt_template = "Hypothesis: {h}\n" \
    #                   "Candidate/potential premises:\n{context}\n" \
    #                   "Condition: {gold_sent_new} are known to be the necessary premises required to deduce the above hypothesis.\n" \
    #                   "Question: If you can deduce the above hypothesis only with the candidate premise {gold_sent_new}, " \
    #                   "reply 'No additional premise is needed' and provide your proof steps, including intermediate conclusions. " \
    #                   "If you need other premise among the above candidates, " \
    #                   "please provide one missing premise using the premise ID with reason, e.g. sent1, " \
    #                   "and tell me the intermediate conclusion you obtained with this additional premise. " \
    #                   "When you reason, please do not assume you know any other knowledge except " \
    #                   "those listed above as the candidate/potential premises."

    # v6
    prompt_system = "Below, you are given a hypothesis and a set of candidate premises. " \
                    "You are requested to deduce the hypothesis from a small premise set from the candidtates. " \
                    "When you reason, please do not assume you know any other knowledge except " \
                    "those premises in the defined small premise set."
    prompt_template = "Hypothesis: {h}\n" \
                      "Condition: {gold_sent_new} are known to be the necessary premises required to deduce the above hypothesis.\n" \
                      "Candidate/potential premises:\n{context}\n" \
                      "Question: If you can deduce the above hypothesis only with the candidate premise {gold_sent_new}, " \
                      "reply 'No additional premise is needed' and provide your proof steps, including intermediate conclusions. " \
                      "If you need other premise among the above candidates, " \
                      "please provide one missing premise using the premise ID with reason, e.g. sent1, " \
                      "and tell me the intermediate conclusion you obtained with this additional premise. " \



    prompt_list = list()
    response = list()
    final_response = list()
    final_predict = list()
    with open(os.path.join(output_dir, input_file_name), "w") as f:
        for idx, ex in enumerate(tqdm(data)):
            context = ''.join(["{}: {}\n".format(k,v) for k,v in ex['contexts'].items()])
            gold_sent_new_num = list()
            for i in ex['gold_sent_new']:
                gold_sent_new_num.extend(list(set(re.compile('[Ss]ent(\d+)').findall(i))))
            gold_sent_new_text = concat_sent(ex['gold_sent_new'])
            prompt1 = prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=gold_sent_new_text)
            # p2 = prompt_conlude.format(gold_sent_new=gold_sent_new_text)
            prompt_list.append([prompt1])

            f.write("{}:\n".format(idx))
            f.write(prompt1)
            # f.write("\n")
            # f.write(p2)
            f.write("\n\n\n")


            this_sent_new_num = gold_sent_new_num.copy()
            while(True):
                while(True):
                    try:
                        r = completions_with_backoff(
                            # r0 = openai.ChatCompletion.create(
                            model=gpt_model,
                            messages=[{"role": "system", "content": prompt_system},
                                      {"role": "user", "content": prompt_template.format(h=ex['hypothesis'], context=context, gold_sent_new=this_sent_new_num)}],
                            n=sc_num
                        )
                        break
                    except Exception as e:
                        print(f"Error was: {e}")
                        print(f"Waiting 10 minutes and try again")
                        time.sleep(600)
                ans_content = [i['message']['content'] for i in r['choices']]
                this_a = [list(set(re.compile('[Ss]ent(\d+)').findall(i))-set(this_sent_new_num)) for i in ans_content]
                # end_of_ex = [no_additional(i) for i in ans_content]
                sc_one = find_sc_one(this_a)
                if sc_one == '':
                    final_predict.append({'idx':idx, 'final_predict':list(set(this_sent_new_num) - set(gold_sent_new_num)), 'ex': ex})
                    final_response.append({'idx':idx, 'final_response':r, 'ex': ex})
                    response.append({'idx':idx, 'response':r, 'ex': ex})
                    break
                else:
                    this_sent_new_num.append(sc_one)
                    response.append({'idx':idx, 'response':r, 'ex': ex})


    with open(os.path.join(output_dir, output_pickle_name), 'wb') as file:
        pickle.dump([final_predict, final_response, response], file)

