import os

# paths
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
# PRETRAINED_DIR = os.path.join(BASE_DIR, 'pretrained')
CHECKPOINT_DIR = os.path.join(BASE_DIR, 'checkpoint')
CACHE_DIR = os.path.join(BASE_DIR, 'cache')
LOG_DIR = os.path.join(BASE_DIR, 'log')
TENSORBOARD_DIR = os.path.join(LOG_DIR, "tensorboard")
PLOT_DIR = os.path.join(BASE_DIR, 'plot')
BK_DIR = os.path.join(BASE_DIR, "backup")
# victim models/trained victim models
VICTIM_MODEL_DIR = CHECKPOINT_DIR

DATA_DIR = os.path.join(BASE_DIR, 'data')

# dataset dir path
ENTBANK_DIR = os.path.join(DATA_DIR, 'entbank', 'entailment_trees_emnlp2021_data_v3')
STRATEGYQA_DIR = os.path.join(DATA_DIR, 'strategyqa')
LSAT_DIR = os.path.join(DATA_DIR, 'lsat')
PRONTOQA_DIR = os.path.join(DATA_DIR, 'prontoqa')



# pretrained models
# BERT_BASE_CASED_DIR = os.path.join(PRETRAINED_DIR, 'bert-base-cased')
# STANFORD_NLP_HOME = os.path.join(PRETRAINED_DIR, 'stanford_corenlp')
# STANFORD_CORENLP_HOME = os.path.join(PRETRAINED_DIR, 'stanford_corenlp', 'stanford-corenlp-full-2018-10-05')
# STANFORD_CORENLP_HOME = os.path.join(BASE_DIR, 'stanford_corenlp', 'stanford-corenlp-full-2020-04-20')

